#include "wifi_manager.hpp"

#include "esp_log.h"
#include "sdkconfig.h"

#include <cstring>

#define WIFI_STACK_SUPPORTED (CONFIG_ESP_WIFI_ENABLED || CONFIG_ESP_HOST_WIFI_ENABLED || CONFIG_ESP_WIFI_REMOTE_ENABLED)

#if WIFI_STACK_SUPPORTED
#include "esp_event.h"
#include "esp_netif.h"
#include "esp_wifi.h"
#include "freertos/FreeRTOS.h"
#include "freertos/event_groups.h"
#include "freertos/task.h"
#include "nvs_flash.h"
#endif

namespace {
constexpr const char *TAG = "WifiManager";

#if WIFI_STACK_SUPPORTED
constexpr EventBits_t WIFI_CONNECTED_BIT = BIT0;
constexpr EventBits_t WIFI_FAIL_BIT = BIT1;
constexpr int WIFI_CONNECT_TIMEOUT_MS = 15000;
constexpr int WIFI_SCAN_RETRY_COUNT = 3;

EventGroupHandle_t s_wifi_event_group = nullptr;

void wifi_event_handler(void *arg, esp_event_base_t event_base, int32_t event_id, void *event_data)
{
    if (event_base == WIFI_EVENT && event_id == WIFI_EVENT_STA_DISCONNECTED) {
        xEventGroupSetBits(s_wifi_event_group, WIFI_FAIL_BIT);
    } else if (event_base == IP_EVENT && event_id == IP_EVENT_STA_GOT_IP) {
        xEventGroupSetBits(s_wifi_event_group, WIFI_CONNECTED_BIT);
    }
}

esp_err_t init_nvs_once()
{
    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ret = nvs_flash_init();
    }
    return ret;
}
#endif
} // namespace

WifiManager::WifiManager() : m_initialized(false), m_netif_initialized(false), m_event_handlers_registered(false)
{
}

bool WifiManager::is_supported() const
{
#if WIFI_STACK_SUPPORTED
    return true;
#else
    return false;
#endif
}

esp_err_t WifiManager::init()
{
#if WIFI_STACK_SUPPORTED
    if (m_initialized) {
        return ESP_OK;
    }

    esp_err_t ret = init_nvs_once();
    if (ret != ESP_OK) {
        return ret;
    }

    ret = esp_event_loop_create_default();
    if (ret != ESP_OK && ret != ESP_ERR_INVALID_STATE) {
        return ret;
    }

    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ret = esp_wifi_init(&cfg);
    if (ret != ESP_OK && ret != ESP_ERR_WIFI_INIT_STATE) {
        return ret;
    }

    if (!s_wifi_event_group) {
        s_wifi_event_group = xEventGroupCreate();
    }

    if (!m_event_handlers_registered) {
        esp_event_handler_instance_register(WIFI_EVENT, ESP_EVENT_ANY_ID, &wifi_event_handler, nullptr, nullptr);
        m_event_handlers_registered = true;
    }

    ret = esp_wifi_set_mode(WIFI_MODE_STA);
    if (ret != ESP_OK) {
        return ret;
    }
    ret = esp_wifi_set_storage(WIFI_STORAGE_RAM);
    if (ret != ESP_OK) {
        return ret;
    }
    ret = esp_wifi_set_ps(WIFI_PS_NONE);
    if (ret != ESP_OK) {
        ESP_LOGW(TAG, "Failed to disable WiFi power save: %s", esp_err_to_name(ret));
    }
    ret = esp_wifi_start();
    if (ret != ESP_OK && ret != ESP_ERR_WIFI_CONN) {
        return ret;
    }

    m_initialized = true;
    return ESP_OK;
#else
    return ESP_ERR_NOT_SUPPORTED;
#endif
}

esp_err_t WifiManager::scan(std::vector<WifiApInfo> &aps)
{
    aps.clear();
#if WIFI_STACK_SUPPORTED
    esp_err_t ret = init();
    if (ret != ESP_OK) {
        return ret;
    }

    wifi_scan_config_t scan_config = {};
    scan_config.show_hidden = true;
    scan_config.scan_type = WIFI_SCAN_TYPE_ACTIVE;
    scan_config.scan_time.active.min = 120;
    scan_config.scan_time.active.max = 500;
    scan_config.scan_time.passive = 500;

    uint16_t ap_count = 0;
    for (int attempt = 1; attempt <= WIFI_SCAN_RETRY_COUNT; ++attempt) {
        ESP_LOGI(TAG, "Starting WiFi scan attempt %d/%d", attempt, WIFI_SCAN_RETRY_COUNT);
        ret = esp_wifi_scan_start(&scan_config, true);
        if (ret != ESP_OK) {
            ESP_LOGW(TAG, "WiFi scan_start failed on attempt %d: %s", attempt, esp_err_to_name(ret));
            vTaskDelay(pdMS_TO_TICKS(300));
            continue;
        }

        ret = esp_wifi_scan_get_ap_num(&ap_count);
        if (ret != ESP_OK) {
            ESP_LOGW(TAG, "WiFi scan_get_ap_num failed on attempt %d: %s", attempt, esp_err_to_name(ret));
            vTaskDelay(pdMS_TO_TICKS(300));
            continue;
        }

        ESP_LOGI(TAG, "WiFi scan attempt %d found %u AP records", attempt, static_cast<unsigned>(ap_count));
        if (ap_count > 0) {
            break;
        }
        vTaskDelay(pdMS_TO_TICKS(500));
    }

    if (ap_count == 0) {
        ESP_LOGW(TAG, "WiFi scan finished with no APs. Check ESP32-C6 hosted firmware/link and 2.4GHz AP availability.");
        return ESP_OK;
    }

    std::vector<wifi_ap_record_t> records(ap_count);
    ret = esp_wifi_scan_get_ap_records(&ap_count, records.data());
    if (ret != ESP_OK) {
        return ret;
    }

    for (int i = 0; i < ap_count; ++i) {
        if (records[i].ssid[0] == '\0') {
            continue;
        }

        WifiApInfo ap;
        ap.ssid = reinterpret_cast<const char *>(records[i].ssid);
        ap.rssi = records[i].rssi;
        ap.channel = records[i].primary;
        ap.secure = records[i].authmode != WIFI_AUTH_OPEN;
        aps.push_back(ap);
    }

    ESP_LOGI(TAG, "Scan finished, found %u visible APs", static_cast<unsigned>(aps.size()));
    return ESP_OK;
#else
    return ESP_ERR_NOT_SUPPORTED;
#endif
}

esp_err_t WifiManager::connect(const std::string &ssid, const std::string &password)
{
#if WIFI_STACK_SUPPORTED
    esp_err_t ret = init();
    if (ret != ESP_OK) {
        return ret;
    }

    if (!m_netif_initialized) {
        ret = esp_netif_init();
        if (ret != ESP_OK && ret != ESP_ERR_INVALID_STATE) {
            return ret;
        }
        if (esp_netif_get_handle_from_ifkey("WIFI_STA_DEF") == nullptr) {
            if (!esp_netif_create_default_wifi_sta()) {
                return ESP_ERR_NO_MEM;
            }
        }
        esp_event_handler_instance_register(IP_EVENT, IP_EVENT_STA_GOT_IP, &wifi_event_handler, nullptr, nullptr);
        m_netif_initialized = true;
    }

    wifi_config_t wifi_config = {};
    strlcpy(reinterpret_cast<char *>(wifi_config.sta.ssid), ssid.c_str(), sizeof(wifi_config.sta.ssid));
    strlcpy(reinterpret_cast<char *>(wifi_config.sta.password), password.c_str(), sizeof(wifi_config.sta.password));
    wifi_config.sta.threshold.authmode = WIFI_AUTH_OPEN;

    xEventGroupClearBits(s_wifi_event_group, WIFI_CONNECTED_BIT | WIFI_FAIL_BIT);
    esp_wifi_disconnect();
    ret = esp_wifi_set_config(WIFI_IF_STA, &wifi_config);
    if (ret != ESP_OK) {
        return ret;
    }

    ret = esp_wifi_connect();
    if (ret != ESP_OK) {
        return ret;
    }

    EventBits_t bits = xEventGroupWaitBits(s_wifi_event_group,
                                           WIFI_CONNECTED_BIT | WIFI_FAIL_BIT,
                                           pdTRUE,
                                           pdFALSE,
                                           pdMS_TO_TICKS(WIFI_CONNECT_TIMEOUT_MS));
    if (bits & WIFI_CONNECTED_BIT) {
        ESP_LOGI(TAG, "Connected to %s", ssid.c_str());
        return ESP_OK;
    }

    if (bits & WIFI_FAIL_BIT) {
        ESP_LOGW(TAG, "Failed to connect to %s", ssid.c_str());
        return ESP_FAIL;
    }

    ESP_LOGW(TAG, "Timed out connecting to %s", ssid.c_str());
    return ESP_ERR_TIMEOUT;
#else
    return ESP_ERR_NOT_SUPPORTED;
#endif
}
