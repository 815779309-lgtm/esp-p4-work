#include "frame_cap_pipeline.hpp"
#include "esp_event.h"
#include "esp_err.h"
#include "esp_log.h"
#include "esp_netif.h"
#include "esp_wifi_default.h"
#include "who_recognition_app_term.hpp"
#include "who_spiflash_fatfs.hpp"
#include "voice_recognition_app.hpp"

#include <unistd.h>

#include "media_lib_adapter.h"
#include "media_lib_os.h"
#include "esp_capture.h"
#include "esp_video_enc_default.h"
#include "esp_audio_enc_default.h"
#include "esp_video_dec_default.h"
#include "esp_audio_dec_default.h"

using namespace who::frame_cap;
using namespace who::app;

namespace {
const char *TAG = "app_main";
}

extern "C" void app_main(void)
{
    vTaskPrioritySet(xTaskGetCurrentTaskHandle(), 5);

    // Register the camera video VFS before SD card and WiFi/LWIP consume VFS slots.
#if CONFIG_IDF_TARGET_ESP32S3
    auto frame_cap = get_dvp_frame_cap_pipeline();
#elif CONFIG_IDF_TARGET_ESP32P4
    auto frame_cap = get_mipi_csi_frame_cap_pipeline();
    // auto frame_cap = get_uvc_frame_cap_pipeline();
#endif

#if CONFIG_DB_FATFS_FLASH
    ESP_ERROR_CHECK(fatfs_flash_mount());
#elif CONFIG_DB_SPIFFS
    ESP_ERROR_CHECK(bsp_spiffs_mount());
#endif
#if CONFIG_DB_FATFS_SDCARD || CONFIG_HUMAN_FACE_DETECT_MODEL_IN_SDCARD || CONFIG_HUMAN_FACE_FEAT_MODEL_IN_SDCARD
    ESP_ERROR_CHECK(bsp_sdcard_mount());
#else
    esp_err_t sd_ret = bsp_sdcard_mount();
    if (sd_ret != ESP_OK) {
        ESP_LOGW(TAG, "SD card not mounted, arm background image will be unavailable: %s", esp_err_to_name(sd_ret));
    }
#endif
    if (access("/sdcard/ARM_BG.bin", F_OK) == 0) {
        ESP_LOGI(TAG, "Found SD card background: /sdcard/ARM_BG.bin");
    } else {
        ESP_LOGW(TAG, "Missing SD card background: /sdcard/ARM_BG.bin");
    }

// close led
#ifdef BSP_BOARD_ESP32_S3_EYE
    ESP_ERROR_CHECK(bsp_leds_init());
    ESP_ERROR_CHECK(bsp_led_set(BSP_LED_GREEN, false));
#endif

    esp_err_t netif_ret = esp_netif_init();
    if (netif_ret != ESP_OK && netif_ret != ESP_ERR_INVALID_STATE) {
        ESP_LOGW(TAG, "esp_netif_init failed before app init: %s", esp_err_to_name(netif_ret));
    }
    esp_err_t event_ret = esp_event_loop_create_default();
    if (event_ret != ESP_OK && event_ret != ESP_ERR_INVALID_STATE) {
        ESP_LOGW(TAG, "esp_event_loop_create_default failed before app init: %s", esp_err_to_name(event_ret));
    }
    if (esp_netif_get_handle_from_ifkey("WIFI_STA_DEF") == nullptr) {
        esp_netif_t *sta_netif = esp_netif_create_default_wifi_sta();
        if (!sta_netif) {
            ESP_LOGW(TAG, "Failed to create default WiFi STA netif before app init");
        }
    }
    media_lib_add_default_adapter();

    // Register default codecs (video/audio encoders and decoders)
    esp_video_enc_register_default();
    esp_audio_enc_register_default();
    esp_video_dec_register_default();
    esp_audio_dec_register_default();

    // Register capture thread scheduler for video encoder and other internal threads
    esp_capture_set_thread_scheduler([](const char *name, esp_capture_thread_schedule_cfg_t *schedule_cfg) {
        media_lib_thread_cfg_t cfg = {
            .priority = schedule_cfg->priority,
            .core_id = schedule_cfg->core_id,
            .stack_size = schedule_cfg->stack_size,
        };
        schedule_cfg->stack_in_ext = true;
        if (strcmp(name, "venc_0") == 0) {
            cfg.stack_size = 20 * 1024;
            cfg.priority = 10;
        }
        schedule_cfg->stack_size = cfg.stack_size;
        schedule_cfg->priority = cfg.priority;
        schedule_cfg->core_id = cfg.core_id;
    });

    // Register thread scheduler for WebRTC peer connection task
    media_lib_thread_set_schedule_cb([](const char *thread_name, media_lib_thread_cfg_t *schedule_cfg) {
        if (strcmp(thread_name, "pc_task") == 0) {
            schedule_cfg->stack_size = 25 * 1024;
            schedule_cfg->priority = 18;
            schedule_cfg->core_id = 1;
        }
    });

    auto recognition_app = new VoiceRecognitionApp(frame_cap);
    // try this if you don't have a lcd.
    // auto recognition_app = new WhoRecognitionAppTerm(frame_cap);
    recognition_app->run();
}