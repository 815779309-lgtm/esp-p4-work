#pragma once

#include "arm_webrtc_streamer.hpp"
#include "who_detect_result_handle.hpp"
#include "who_frame_lcd_disp.hpp"
#include "voice_control.hpp"
#include "wifi_manager.hpp"
#include "who_recognition_app_base.hpp"
#include "who_text_result_handle.hpp"

#include <string>
#include <vector>

class VoiceRecognitionApp : public who::app::WhoRecognitionAppBase {
public:
    explicit VoiceRecognitionApp(who::frame_cap::WhoFrameCap *frame_cap);
    ~VoiceRecognitionApp();
    bool run() override;

private:
    enum class Screen {
        LOGIN,
        PASSWORD,
        HOME,
        FACE_LOGIN,
        ENROLL,
        ARM_CONTROL,
        WIFI,
    };

    static void lv_event_cb(lv_event_t *e);
    void create_ui();
    void create_login_screen();
    void create_password_screen();
    void create_home_screen();
    void create_wifi_screen();
    void create_camera_overlay();
    lv_obj_t *create_button(lv_obj_t *parent, const char *text, lv_event_code_t filter, void *user_data);
    void show_screen(Screen screen);
    void update_detection_task();
    void verify_password();
    void start_wifi_scan();
    void start_wifi_connect();
    void finish_wifi_scan(esp_err_t result, std::vector<WifiApInfo> aps);
    void finish_wifi_connect(esp_err_t result, const std::string &ssid);
    void set_status(const char *text);
    void trigger_recognition_event(EventBits_t event);
    void recognition_result_cb(const std::string &result);
    void detect_result_cb(const who::detect::WhoDetect::result_t &result);
    void lcd_disp_cb(who::cam::cam_fb_t *fb);
    void cleanup_recognition_result();
    void cleanup_detect_result();
    static void wifi_scan_task(void *arg);
    static void wifi_connect_task(void *arg);

    who::lcd_disp::WhoFrameLCDDisp *m_lcd_disp;
    ArmWebRTCStreamer *m_arm_streamer;
    who::lcd_disp::WhoTextResultLCDDisp *m_text_result_lcd_disp;
    who::lcd_disp::WhoDetectResultLCDDisp *m_detect_result_lcd_disp;
    VoiceControl m_voice;
    WifiManager m_wifi;
    lv_obj_t *m_login_panel;
    lv_obj_t *m_password_panel;
    lv_obj_t *m_home_panel;
    lv_obj_t *m_wifi_panel;
    lv_obj_t *m_camera_panel;
    lv_obj_t *m_arm_background;
    lv_image_dsc_t m_bg_img_dsc;
    uint8_t *m_bg_img_data;
    lv_obj_t *m_status_label;
    lv_obj_t *m_password_ta;
    lv_obj_t *m_wifi_dropdown;
    lv_obj_t *m_wifi_password_ta;
    lv_obj_t *m_wifi_status_label;
    lv_obj_t *m_keyboard;
    lv_obj_t *m_camera_title;
    lv_obj_t *m_enroll_hint;
    Screen m_screen;
    int64_t m_last_face_announce_us;
    std::vector<WifiApInfo> m_wifi_aps;
    std::string m_pending_wifi_ssid;
    std::string m_pending_wifi_password;
    bool m_wifi_scan_running;
    bool m_wifi_connect_running;
};