﻿#include "voice_recognition_app.hpp"
#include "esp_timer.h"
#include "who_recognition.hpp"
#include "esp_log.h"
#include "esp_err.h"
#include "esp_heap_caps.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#if 0
VoiceRecognitionApp::VoiceRecognitionApp(who::frame_cap::WhoFrameCap *frame_cap) :
    WhoRecognitionAppLCD(frame_cap), m_last_face_announce_us(0)
{
}

bool VoiceRecognitionApp::run()
{
    bool ret = WhoRecognitionAppLCD::run();
    ret &= m_voice.start([this](EventBits_t event) { trigger_recognition_event(event); });
    return ret;
}

void VoiceRecognitionApp::detect_result_cb(const who::detect::WhoDetect::result_t &result)
{
    WhoRecognitionAppLCD::detect_result_cb(result);

    if (result.det_res.empty()) {
        return;
    }

    int64_t now = esp_timer_get_time();
    if (now - m_last_face_announce_us > 3000000) {
        m_last_face_announce_us = now;
    }
}

void VoiceRecognitionApp::trigger_recognition_event(EventBits_t event)
{
    auto task = m_recognition->get_recognition_task();
    if (task && task->is_active()) {
        xEventGroupSetBits(task->get_event_group(), event);
    }
}
#endif

#include "human_face_detect.hpp"
#include "lvgl.h"
#include "who_lvgl_utils.hpp"
#include "who_yield2idle.hpp"

LV_FONT_DECLARE(montserrat_bold_20);
LV_FONT_DECLARE(montserrat_bold_26);

namespace {
constexpr const char *TAG = "VoiceRecognitionApp";
constexpr const char *PASSWORD = "ESP32P4";
constexpr const char *ARM_BACKGROUND_PATH = "P:/ARM_BG.bin";

void log_background_status()
{
    ESP_LOGI(TAG, "RGB565 background mode: using LV_COLOR_FORMAT_RGB565");

    lv_fs_file_t bg_file;
    lv_fs_res_t bg_res = lv_fs_open(&bg_file, ARM_BACKGROUND_PATH, LV_FS_MODE_RD);
    if (bg_res == LV_FS_RES_OK) {
        uint32_t file_size = 0;
        lv_fs_seek(&bg_file, 0, LV_FS_SEEK_END);
        lv_fs_tell(&bg_file, &file_size);
        lv_fs_close(&bg_file);

        uint32_t expected_size = LV_HOR_RES * LV_VER_RES * 2;
        ESP_LOGI(TAG, "Found background file: %s, size=%u bytes", ARM_BACKGROUND_PATH, file_size);
        ESP_LOGI(TAG, "Display resolution: %dx%d, expected RGB565 size: %u bytes",
                 LV_HOR_RES, LV_VER_RES, expected_size);
        if (file_size == expected_size) {
            ESP_LOGI(TAG, "Background file size matches display resolution");
        } else {
            ESP_LOGW(TAG, "Background file size %u does not match expected %u", file_size, expected_size);
        }
    } else {
        ESP_LOGW(TAG, "Cannot open background file %s, fs_res=%d", ARM_BACKGROUND_PATH, static_cast<int>(bg_res));
    }
}

void log_heap_status(const char *label)
{
    ESP_LOGI(TAG,
             "%s heap: internal=%u largest_internal=%u psram=%u largest_psram=%u",
             label,
             static_cast<unsigned>(heap_caps_get_free_size(MALLOC_CAP_INTERNAL)),
             static_cast<unsigned>(heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL)),
             static_cast<unsigned>(heap_caps_get_free_size(MALLOC_CAP_SPIRAM)),
             static_cast<unsigned>(heap_caps_get_largest_free_block(MALLOC_CAP_SPIRAM)));
}
} // namespace

VoiceRecognitionApp::VoiceRecognitionApp(who::frame_cap::WhoFrameCap *frame_cap) :
    WhoRecognitionAppBase(frame_cap),
    m_lcd_disp(new who::lcd_disp::WhoFrameLCDDisp("LCDDisp", frame_cap->get_last_node(), 1)),
    m_arm_streamer(nullptr),
    m_text_result_lcd_disp(nullptr),
    m_detect_result_lcd_disp(nullptr),
    m_login_panel(nullptr),
    m_password_panel(nullptr),
    m_home_panel(nullptr),
    m_wifi_panel(nullptr),
    m_camera_panel(nullptr),
    m_arm_background(nullptr),
    m_bg_img_dsc{},
    m_bg_img_data(nullptr),
    m_status_label(nullptr),
    m_password_ta(nullptr),
    m_wifi_dropdown(nullptr),
    m_wifi_password_ta(nullptr),
    m_wifi_status_label(nullptr),
    m_keyboard(nullptr),
    m_camera_title(nullptr),
    m_enroll_hint(nullptr),
    m_screen(Screen::LOGIN),
    m_last_face_announce_us(0),
    m_wifi_scan_running(false),
    m_wifi_connect_running(false)
{
    WhoApp::add_task(m_lcd_disp);
    m_lcd_disp->set_lcd_disp_cb(std::bind(&VoiceRecognitionApp::lcd_disp_cb, this, std::placeholders::_1));

    char db_path[64];
#if CONFIG_DB_FATFS_FLASH
    snprintf(db_path, sizeof(db_path), "%s/face.db", CONFIG_SPIFLASH_MOUNT_POINT);
#elif CONFIG_DB_SPIFFS
    snprintf(db_path, sizeof(db_path), "%s/face.db", CONFIG_BSP_SPIFFS_MOUNT_POINT);
#else
    snprintf(db_path, sizeof(db_path), "%s/face.db", CONFIG_BSP_SD_MOUNT_POINT);
#endif

    m_recognition->set_recognizer(new HumanFaceRecognizer(
        db_path, static_cast<HumanFaceFeat::model_type_t>(CONFIG_DEFAULT_HUMAN_FACE_FEAT_MODEL), false));
    m_recognition->set_detect_model(
        new HumanFaceDetect(static_cast<HumanFaceDetect::model_type_t>(CONFIG_DEFAULT_HUMAN_FACE_DETECT_MODEL), false));

    auto recognition_task = m_recognition->get_recognition_task();
    auto detect_task = m_recognition->get_detect_task();
    detect_task->set_fps(3.0f);
#if CONFIG_IDF_TARGET_ESP32P4
    int disp_n_frames = 30;
#else
    int disp_n_frames = 60;
#endif

    create_ui();
    m_text_result_lcd_disp = new who::lcd_disp::WhoTextResultLCDDisp(recognition_task, m_status_label, disp_n_frames);
    m_detect_result_lcd_disp =
        new who::lcd_disp::WhoDetectResultLCDDisp(detect_task, m_lcd_disp->get_canvas(), {{255, 65, 65}});

    recognition_task->set_recognition_result_cb(
        std::bind(&VoiceRecognitionApp::recognition_result_cb, this, std::placeholders::_1));
    recognition_task->set_detect_result_cb(
        std::bind(&VoiceRecognitionApp::detect_result_cb, this, std::placeholders::_1));
    recognition_task->set_cleanup_func(std::bind(&VoiceRecognitionApp::cleanup_recognition_result, this));
    detect_task->set_detect_result_cb(std::bind(&VoiceRecognitionApp::detect_result_cb, this, std::placeholders::_1));
    detect_task->set_cleanup_func(std::bind(&VoiceRecognitionApp::cleanup_detect_result, this));
}

VoiceRecognitionApp::~VoiceRecognitionApp()
{
    m_voice.stop();
    if (m_arm_streamer) {
        m_arm_streamer->stop();
    }
    heap_caps_free(m_bg_img_data);
    delete m_arm_streamer;
    delete m_text_result_lcd_disp;
    delete m_detect_result_lcd_disp;
    delete m_lcd_disp;
}

bool VoiceRecognitionApp::run()
{
    bool ret = who::WhoYield2Idle::get_instance()->run();
    ret &= m_recognition->get_detect_task()->run(8192, 2, 1);
    update_detection_task();
    ret &= m_recognition->get_recognition_task()->run(8192, 2, 1);
    for (const auto &frame_cap_node : m_frame_cap->get_all_nodes()) {
        ret &= frame_cap_node->run(4096, 2, 0);
    }
    ret &= m_lcd_disp->run(2560, 2, 0);
    update_detection_task();
    ret &= m_voice.start([this](EventBits_t event) { trigger_recognition_event(event); });
    return ret;
}

void VoiceRecognitionApp::lv_event_cb(lv_event_t *e)
{
    auto *app = static_cast<VoiceRecognitionApp *>(lv_event_get_user_data(e));
    lv_obj_t *obj = lv_event_get_target_obj(e);

    if (obj == app->m_password_ta) {
        lv_keyboard_set_mode(app->m_keyboard, LV_KEYBOARD_MODE_TEXT_UPPER);
        lv_keyboard_set_textarea(app->m_keyboard, app->m_password_ta);
        return;
    }

    if (obj == app->m_wifi_password_ta) {
        lv_keyboard_set_mode(app->m_keyboard, LV_KEYBOARD_MODE_TEXT_LOWER);
        lv_keyboard_set_textarea(app->m_keyboard, app->m_wifi_password_ta);
        lv_obj_clear_flag(app->m_keyboard, LV_OBJ_FLAG_HIDDEN);
        lv_obj_move_foreground(app->m_keyboard);
        return;
    }

    const char *action = static_cast<const char *>(lv_obj_get_user_data(obj));
    if (!action) {
        return;
    }

    if (strcmp(action, "password") == 0) {
        app->show_screen(Screen::PASSWORD);
    } else if (strcmp(action, "face_login") == 0) {
        app->show_screen(Screen::FACE_LOGIN);
        app->set_status("Face login: looking for a registered face...");
        app->trigger_recognition_event(who::recognition::WhoRecognitionCore::RECOGNIZE);
    } else if (strcmp(action, "password_ok") == 0) {
        app->verify_password();
    } else if (strcmp(action, "back_login") == 0) {
        app->show_screen(Screen::LOGIN);
    } else if (strcmp(action, "enroll") == 0) {
        app->show_screen(Screen::ENROLL);
        app->set_status("Face enrollment: keep one face in view.");
        app->trigger_recognition_event(who::recognition::WhoRecognitionCore::ENROLL);
    } else if (strcmp(action, "arm") == 0) {
        app->show_screen(Screen::ARM_CONTROL);
        app->set_status("WHIP video publish enabled.");
    } else if (strcmp(action, "wifi") == 0) {
        app->show_screen(Screen::WIFI);
    } else if (strcmp(action, "wifi_scan") == 0) {
        lv_obj_add_flag(app->m_keyboard, LV_OBJ_FLAG_HIDDEN);
        app->start_wifi_scan();
    } else if (strcmp(action, "wifi_connect") == 0) {
        lv_obj_add_flag(app->m_keyboard, LV_OBJ_FLAG_HIDDEN);
        app->start_wifi_connect();
    } else if (strcmp(action, "camera_back") == 0) {
        if (app->m_screen == Screen::FACE_LOGIN) {
            app->show_screen(Screen::LOGIN);
        } else {
            app->show_screen(Screen::HOME);
        }
    } else if (strcmp(action, "home") == 0) {
        lv_obj_add_flag(app->m_keyboard, LV_OBJ_FLAG_HIDDEN);
        app->show_screen(Screen::HOME);
    }
}

lv_obj_t *VoiceRecognitionApp::create_button(lv_obj_t *parent,
                                             const char *text,
                                             lv_event_code_t filter,
                                             void *user_data)
{
    lv_obj_t *btn = lv_button_create(parent);
    lv_obj_set_user_data(btn, user_data);
    lv_obj_set_height(btn, 58);
    lv_obj_set_style_radius(btn, 8, LV_PART_MAIN);
    lv_obj_set_style_bg_color(btn, lv_color_hex(0x2563eb), LV_PART_MAIN);
    lv_obj_set_style_bg_color(btn, lv_color_hex(0x1d4ed8), LV_STATE_PRESSED);
    lv_obj_t *label = lv_label_create(btn);
    lv_label_set_text(label, text);
    lv_obj_set_style_text_font(label, &montserrat_bold_20, LV_PART_MAIN);
    lv_obj_center(label);
    lv_obj_add_event_cb(btn, lv_event_cb, filter, this);
    return btn;
}

void VoiceRecognitionApp::create_ui()
{
    bsp_display_lock(0);
    lv_obj_t *scr = lv_scr_act();
    lv_obj_set_style_bg_color(scr, lv_color_hex(0x111827), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(scr, LV_OPA_COVER, LV_PART_MAIN);

    lv_obj_add_flag(m_lcd_disp->get_canvas(), LV_OBJ_FLAG_HIDDEN);
    lv_obj_move_to_index(m_lcd_disp->get_canvas(), 0);

    m_arm_background = lv_image_create(scr);

    // Load raw RGB565 background image from file
    lv_fs_file_t bg_file;
    lv_fs_res_t fs_res = lv_fs_open(&bg_file, ARM_BACKGROUND_PATH, LV_FS_MODE_RD);
    if (fs_res == LV_FS_RES_OK) {
        uint32_t file_size;
        lv_fs_seek(&bg_file, 0, LV_FS_SEEK_END);
        lv_fs_tell(&bg_file, &file_size);
        lv_fs_seek(&bg_file, 0, LV_FS_SEEK_SET);

        const uint32_t expected_size = LV_HOR_RES * LV_VER_RES * sizeof(uint16_t);
        if (file_size >= expected_size) {
            m_bg_img_data = static_cast<uint8_t *>(heap_caps_malloc(expected_size, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
            if (!m_bg_img_data) {
                m_bg_img_data = static_cast<uint8_t *>(heap_caps_malloc(expected_size, MALLOC_CAP_8BIT));
            }
            if (m_bg_img_data) {
                uint32_t bytes_read;
                lv_fs_read(&bg_file, m_bg_img_data, expected_size, &bytes_read);

                m_bg_img_dsc.header.magic = LV_IMAGE_HEADER_MAGIC;
                m_bg_img_dsc.header.cf = LV_COLOR_FORMAT_RGB565;
                m_bg_img_dsc.header.flags = 0;
                m_bg_img_dsc.header.w = LV_HOR_RES;
                m_bg_img_dsc.header.h = LV_VER_RES;
                m_bg_img_dsc.header.stride = LV_HOR_RES * sizeof(uint16_t);
                m_bg_img_dsc.header.reserved_2 = 0;
                m_bg_img_dsc.data_size = expected_size;
                m_bg_img_dsc.data = m_bg_img_data;
                m_bg_img_dsc.reserved = nullptr;
                m_bg_img_dsc.reserved_2 = nullptr;

                lv_image_set_src(m_arm_background, &m_bg_img_dsc);
                ESP_LOGI(TAG, "Background loaded: %u bytes", static_cast<unsigned>(expected_size));
            }
        }
        lv_fs_close(&bg_file);
    } else {
        ESP_LOGW(TAG, "Cannot open RGB565 background file: %s (fs_res=%d)",
                 ARM_BACKGROUND_PATH, static_cast<int>(fs_res));
    }

    lv_obj_set_size(m_arm_background, LV_PCT(100), LV_PCT(100));
    lv_image_set_inner_align(m_arm_background, LV_IMAGE_ALIGN_COVER);
    lv_obj_set_style_image_opa(m_arm_background, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_clear_flag(m_arm_background, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_move_to_index(m_arm_background, 1);
    log_background_status();

    create_login_screen();
    create_password_screen();
    create_home_screen();
    create_wifi_screen();
    create_camera_overlay();
    show_screen(Screen::LOGIN);
    bsp_display_unlock();
}

void VoiceRecognitionApp::create_login_screen()
{
    lv_obj_t *scr = lv_scr_act();
    m_login_panel = lv_obj_create(scr);
    lv_obj_set_size(m_login_panel, LV_PCT(100), LV_PCT(100));
    lv_obj_set_style_bg_color(m_login_panel, lv_color_hex(0x111827), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(m_login_panel, LV_OPA_TRANSP, LV_PART_MAIN);
    lv_obj_set_style_border_width(m_login_panel, 0, LV_PART_MAIN);
    lv_obj_set_flex_flow(m_login_panel, LV_FLEX_FLOW_COLUMN);
    lv_obj_set_flex_align(m_login_panel, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
    lv_obj_set_style_pad_gap(m_login_panel, 18, LV_PART_MAIN);

    lv_obj_t *title = lv_label_create(m_login_panel);
    lv_label_set_text(title, "Login");
    lv_obj_set_style_text_color(title, lv_color_white(), LV_PART_MAIN);
    lv_obj_set_style_text_font(title, &montserrat_bold_26, LV_PART_MAIN);

    create_button(m_login_panel, "Password Login", LV_EVENT_CLICKED, (void *)"password");
    create_button(m_login_panel, "Face Login", LV_EVENT_CLICKED, (void *)"face_login");
}

void VoiceRecognitionApp::create_password_screen()
{
    lv_obj_t *scr = lv_scr_act();
    m_password_panel = lv_obj_create(scr);
    lv_obj_set_size(m_password_panel, LV_PCT(100), LV_PCT(58));
    lv_obj_align(m_password_panel, LV_ALIGN_TOP_MID, 0, 0);
    lv_obj_set_style_bg_color(m_password_panel, lv_color_hex(0x111827), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(m_password_panel, LV_OPA_TRANSP, LV_PART_MAIN);
    lv_obj_set_style_border_width(m_password_panel, 0, LV_PART_MAIN);
    lv_obj_set_flex_flow(m_password_panel, LV_FLEX_FLOW_COLUMN);
    lv_obj_set_flex_align(m_password_panel, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
    lv_obj_set_style_pad_gap(m_password_panel, 14, LV_PART_MAIN);

    lv_obj_t *title = lv_label_create(m_password_panel);
    lv_label_set_text(title, "Password Login");
    lv_obj_set_style_text_color(title, lv_color_white(), LV_PART_MAIN);
    lv_obj_set_style_text_font(title, &montserrat_bold_26, LV_PART_MAIN);

    m_password_ta = lv_textarea_create(m_password_panel);
    lv_textarea_set_password_mode(m_password_ta, true);
    lv_textarea_set_one_line(m_password_ta, true);
    lv_textarea_set_placeholder_text(m_password_ta, "");
    lv_obj_set_width(m_password_ta, LV_PCT(48));
    lv_obj_set_height(m_password_ta, 54);
    lv_obj_add_event_cb(m_password_ta, lv_event_cb, LV_EVENT_FOCUSED, this);

    create_button(m_password_panel, "Login", LV_EVENT_CLICKED, (void *)"password_ok");
    create_button(m_password_panel, "Back", LV_EVENT_CLICKED, (void *)"back_login");

    m_keyboard = lv_keyboard_create(scr);
    lv_keyboard_set_mode(m_keyboard, LV_KEYBOARD_MODE_TEXT_UPPER);
    lv_keyboard_set_textarea(m_keyboard, m_password_ta);
    lv_obj_add_flag(m_keyboard, LV_OBJ_FLAG_HIDDEN);
}

void VoiceRecognitionApp::create_home_screen()
{
    lv_obj_t *scr = lv_scr_act();
    m_home_panel = lv_obj_create(scr);
    lv_obj_set_size(m_home_panel, LV_PCT(100), LV_PCT(100));
    lv_obj_set_style_bg_color(m_home_panel, lv_color_hex(0x0f172a), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(m_home_panel, LV_OPA_TRANSP, LV_PART_MAIN);
    lv_obj_set_style_border_width(m_home_panel, 0, LV_PART_MAIN);
    lv_obj_set_flex_flow(m_home_panel, LV_FLEX_FLOW_COLUMN);
    lv_obj_set_flex_align(m_home_panel, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
    lv_obj_set_style_pad_gap(m_home_panel, 18, LV_PART_MAIN);

    lv_obj_t *title = lv_label_create(m_home_panel);
    lv_label_set_text(title, "Main Menu");
    lv_obj_set_style_text_color(title, lv_color_white(), LV_PART_MAIN);
    lv_obj_set_style_text_font(title, &montserrat_bold_26, LV_PART_MAIN);

    create_button(m_home_panel, "Face Enrollment", LV_EVENT_CLICKED, (void *)"enroll");
    create_button(m_home_panel, "Arm Control", LV_EVENT_CLICKED, (void *)"arm");
    create_button(m_home_panel, "WiFi Setup", LV_EVENT_CLICKED, (void *)"wifi");
    create_button(m_home_panel, "Logout", LV_EVENT_CLICKED, (void *)"back_login");
}

void VoiceRecognitionApp::create_wifi_screen()
{
    lv_obj_t *scr = lv_scr_act();
    m_wifi_panel = lv_obj_create(scr);
    lv_obj_set_size(m_wifi_panel, LV_PCT(100), LV_PCT(58));
    lv_obj_align(m_wifi_panel, LV_ALIGN_TOP_MID, 0, 0);
    lv_obj_set_style_bg_color(m_wifi_panel, lv_color_hex(0x0f172a), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(m_wifi_panel, LV_OPA_TRANSP, LV_PART_MAIN);
    lv_obj_set_style_border_width(m_wifi_panel, 0, LV_PART_MAIN);
    lv_obj_set_flex_flow(m_wifi_panel, LV_FLEX_FLOW_COLUMN);
    lv_obj_set_flex_align(m_wifi_panel, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
    lv_obj_set_style_pad_gap(m_wifi_panel, 14, LV_PART_MAIN);

    lv_obj_t *title = lv_label_create(m_wifi_panel);
    lv_label_set_text(title, "WiFi Setup");
    lv_obj_set_style_text_color(title, lv_color_white(), LV_PART_MAIN);
    lv_obj_set_style_text_font(title, &montserrat_bold_26, LV_PART_MAIN);

    m_wifi_dropdown = lv_dropdown_create(m_wifi_panel);
    lv_obj_set_width(m_wifi_dropdown, LV_PCT(58));
    lv_dropdown_set_options(m_wifi_dropdown, "No networks scanned");

    m_wifi_password_ta = lv_textarea_create(m_wifi_panel);
    lv_textarea_set_password_mode(m_wifi_password_ta, true);
    lv_textarea_set_one_line(m_wifi_password_ta, true);
    lv_textarea_set_placeholder_text(m_wifi_password_ta, "WiFi password");
    lv_obj_set_width(m_wifi_password_ta, LV_PCT(58));
    lv_obj_set_height(m_wifi_password_ta, 54);
    lv_obj_add_event_cb(m_wifi_password_ta, lv_event_cb, LV_EVENT_FOCUSED, this);

    lv_obj_t *row = lv_obj_create(m_wifi_panel);
    lv_obj_set_size(row, LV_PCT(60), 64);
    lv_obj_set_style_bg_opa(row, LV_OPA_TRANSP, LV_PART_MAIN);
    lv_obj_set_style_border_width(row, 0, LV_PART_MAIN);
    lv_obj_set_flex_flow(row, LV_FLEX_FLOW_ROW);
    lv_obj_set_flex_align(row, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
    lv_obj_set_style_pad_gap(row, 12, LV_PART_MAIN);

    lv_obj_t *scan_btn = create_button(row, "Scan", LV_EVENT_CLICKED, (void *)"wifi_scan");
    lv_obj_set_size(scan_btn, 150, 56);
    lv_obj_t *connect_btn = create_button(row, "Connect", LV_EVENT_CLICKED, (void *)"wifi_connect");
    lv_obj_set_size(connect_btn, 180, 56);
    lv_obj_t *back_btn = create_button(row, "Back", LV_EVENT_CLICKED, (void *)"home");
    lv_obj_set_size(back_btn, 140, 56);

    m_wifi_status_label = lv_label_create(m_wifi_panel);
    lv_obj_set_width(m_wifi_status_label, LV_PCT(70));
    lv_label_set_long_mode(m_wifi_status_label, LV_LABEL_LONG_WRAP);
    lv_obj_set_style_text_align(m_wifi_status_label, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN);
    lv_obj_set_style_text_color(m_wifi_status_label, lv_color_white(), LV_PART_MAIN);
    lv_obj_set_style_text_font(m_wifi_status_label, &montserrat_bold_20, LV_PART_MAIN);
    if (m_wifi.is_supported()) {
        lv_label_set_text(m_wifi_status_label, "Tap Scan to search nearby networks.");
    } else {
        lv_label_set_text(m_wifi_status_label, "WiFi stack is disabled. Enable ESP Host WiFi for ESP32-P4.");
    }
}

void VoiceRecognitionApp::create_camera_overlay()
{
    lv_obj_t *scr = lv_scr_act();
    m_camera_panel = lv_obj_create(scr);
    lv_obj_set_size(m_camera_panel, LV_PCT(100), LV_PCT(100));
    lv_obj_set_style_bg_opa(m_camera_panel, LV_OPA_TRANSP, LV_PART_MAIN);
    lv_obj_set_style_border_width(m_camera_panel, 0, LV_PART_MAIN);
    lv_obj_clear_flag(m_camera_panel, LV_OBJ_FLAG_SCROLLABLE);

    m_camera_title = lv_label_create(m_camera_panel);
    lv_obj_align(m_camera_title, LV_ALIGN_TOP_LEFT, 16, 14);
    lv_obj_set_style_text_color(m_camera_title, lv_color_white(), LV_PART_MAIN);
    lv_obj_set_style_text_font(m_camera_title, &montserrat_bold_26, LV_PART_MAIN);

    m_status_label = lv_label_create(m_camera_panel);
    lv_obj_set_width(m_status_label, LV_PCT(70));
    lv_obj_align(m_status_label, LV_ALIGN_BOTTOM_MID, 0, -18);
    lv_label_set_long_mode(m_status_label, LV_LABEL_LONG_WRAP);
    lv_obj_set_style_text_align(m_status_label, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN);
    lv_obj_set_style_text_color(m_status_label, lv_color_white(), LV_PART_MAIN);
    lv_obj_set_style_text_font(m_status_label, &montserrat_bold_20, LV_PART_MAIN);

    m_enroll_hint = create_button(m_camera_panel, "Enroll Again", LV_EVENT_CLICKED, (void *)"enroll");
    lv_obj_set_size(m_enroll_hint, 180, 56);
    lv_obj_align(m_enroll_hint, LV_ALIGN_TOP_RIGHT, -16, 16);

    lv_obj_t *back = create_button(m_camera_panel, "Back", LV_EVENT_CLICKED, (void *)"camera_back");
    lv_obj_set_size(back, 120, 56);
    lv_obj_align(back, LV_ALIGN_BOTTOM_LEFT, 16, -16);
}

void VoiceRecognitionApp::show_screen(Screen screen)
{
    m_screen = screen;
    bool camera_visible = screen == Screen::FACE_LOGIN || screen == Screen::ENROLL;
    bool background_visible = screen == Screen::LOGIN || screen == Screen::PASSWORD || screen == Screen::HOME ||
                              screen == Screen::WIFI || screen == Screen::ARM_CONTROL;

    lv_obj_add_flag(m_login_panel, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(m_password_panel, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(m_home_panel, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(m_wifi_panel, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(m_camera_panel, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(m_keyboard, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(m_lcd_disp->get_canvas(), LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(m_arm_background, LV_OBJ_FLAG_HIDDEN);

    if (screen == Screen::ARM_CONTROL) {
        log_heap_status("Before arm isolation");
        m_voice.stop();
        m_recognition->get_detect_task()->stop();
        m_recognition->get_recognition_task()->stop();
        log_heap_status("After arm isolation");
        if (!m_arm_streamer) {
            // WhoYield2Idle must be paused before creating a new WhoTask,
            // otherwise WhoTask constructor -> start_monitor -> register_task
            // will assert because WhoYield2Idle is active.
            who::WhoYield2Idle::get_instance()->pause();
            m_arm_streamer = new ArmWebRTCStreamer("ArmWebRTCStreamer", m_frame_cap->get_last_node(), 1);
            who::WhoYield2Idle::get_instance()->resume();
        }
        m_arm_streamer->run(8192, 1, 1);
        m_arm_streamer->set_enabled(true);
    } else if (m_arm_streamer) {
        m_arm_streamer->set_enabled(false);
        m_arm_streamer->stop();
        delete m_arm_streamer;
        m_arm_streamer = nullptr;
        m_recognition->get_detect_task()->run(8192, 2, 1);
        m_recognition->get_recognition_task()->run(8192, 2, 1);
        m_voice.start([this](EventBits_t event) { trigger_recognition_event(event); });
    }

    if (background_visible) {
        lv_obj_clear_flag(m_arm_background, LV_OBJ_FLAG_HIDDEN);
        lv_obj_move_to_index(m_lcd_disp->get_canvas(), 0);
        lv_obj_move_to_index(m_arm_background, 1);
    }

    if (screen == Screen::LOGIN) {
        lv_obj_clear_flag(m_login_panel, LV_OBJ_FLAG_HIDDEN);
    } else if (screen == Screen::PASSWORD) {
        lv_obj_clear_flag(m_password_panel, LV_OBJ_FLAG_HIDDEN);
        lv_obj_clear_flag(m_keyboard, LV_OBJ_FLAG_HIDDEN);
        lv_obj_move_foreground(m_keyboard);
    } else if (screen == Screen::HOME) {
        lv_obj_clear_flag(m_home_panel, LV_OBJ_FLAG_HIDDEN);
    } else if (screen == Screen::WIFI) {
        lv_obj_clear_flag(m_wifi_panel, LV_OBJ_FLAG_HIDDEN);
        lv_keyboard_set_mode(m_keyboard, LV_KEYBOARD_MODE_TEXT_LOWER);
        lv_keyboard_set_textarea(m_keyboard, m_wifi_password_ta);
    } else if (screen == Screen::ARM_CONTROL) {
        lv_obj_clear_flag(m_camera_panel, LV_OBJ_FLAG_HIDDEN);
        lv_obj_move_foreground(m_camera_panel);
        lv_obj_add_flag(m_enroll_hint, LV_OBJ_FLAG_HIDDEN);
        lv_label_set_text(m_camera_title, "Arm Control");
        set_status("Publishing arm-control video by WHIP/WebRTC.");
    } else if (camera_visible) {
        lv_obj_clear_flag(m_lcd_disp->get_canvas(), LV_OBJ_FLAG_HIDDEN);
        lv_obj_move_to_index(m_lcd_disp->get_canvas(), 0);
        lv_obj_clear_flag(m_camera_panel, LV_OBJ_FLAG_HIDDEN);
        lv_obj_move_foreground(m_camera_panel);

        lv_obj_add_flag(m_enroll_hint, LV_OBJ_FLAG_HIDDEN);
        if (screen == Screen::FACE_LOGIN) {
            lv_label_set_text(m_camera_title, "Face Login");
        } else if (screen == Screen::ENROLL) {
            lv_label_set_text(m_camera_title, "Face Enrollment");
            lv_obj_clear_flag(m_enroll_hint, LV_OBJ_FLAG_HIDDEN);
        } else {
            lv_label_set_text(m_camera_title, "Arm Control");
            set_status("Publishing arm-control video by WHIP/WebRTC.");
        }
    }
    update_detection_task();
}

void VoiceRecognitionApp::update_detection_task()
{
    auto detect_task = m_recognition->get_detect_task();
    const bool need_face_detection = m_screen == Screen::FACE_LOGIN || m_screen == Screen::ENROLL;
    if (detect_task) {
        if (need_face_detection) {
            detect_task->resume();
        } else {
            detect_task->pause_async();
        }
    }

    if (m_lcd_disp) {
        m_lcd_disp->resume();
    }
}

void VoiceRecognitionApp::verify_password()
{
    const char *input = lv_textarea_get_text(m_password_ta);
    if (strcmp(input, PASSWORD) == 0) {
        lv_textarea_set_text(m_password_ta, "");
        show_screen(Screen::HOME);
    } else {
        lv_textarea_set_text(m_password_ta, "");
        ESP_LOGW(TAG, "Password login failed");
    }
}

void VoiceRecognitionApp::start_wifi_scan()
{
    if (m_wifi_scan_running) {
        lv_label_set_text(m_wifi_status_label, "Scanning is already running...");
        return;
    }

    m_wifi_scan_running = true;
    lv_label_set_text(m_wifi_status_label, "Scanning nearby WiFi networks...");
    if (xTaskCreate(wifi_scan_task, "wifi_scan_ui", 4096, this, 4, nullptr) != pdPASS) {
        m_wifi_scan_running = false;
        lv_label_set_text(m_wifi_status_label, "Failed to start WiFi scan task.");
    }
}

void VoiceRecognitionApp::start_wifi_connect()
{
    if (m_wifi_connect_running) {
        lv_label_set_text(m_wifi_status_label, "Connection is already running...");
        return;
    }

    if (m_wifi_aps.empty()) {
        lv_label_set_text(m_wifi_status_label, "Scan and choose a network first.");
        return;
    }

    uint16_t selected = lv_dropdown_get_selected(m_wifi_dropdown);
    if (selected >= m_wifi_aps.size()) {
        lv_label_set_text(m_wifi_status_label, "Invalid WiFi selection.");
        return;
    }

    m_pending_wifi_ssid = m_wifi_aps[selected].ssid;
    m_pending_wifi_password = lv_textarea_get_text(m_wifi_password_ta);
    m_wifi_connect_running = true;
    lv_label_set_text_fmt(m_wifi_status_label, "Connecting to %s...", m_pending_wifi_ssid.c_str());
    if (xTaskCreate(wifi_connect_task, "wifi_connect_ui", 4096, this, 4, nullptr) != pdPASS) {
        m_wifi_connect_running = false;
        lv_label_set_text(m_wifi_status_label, "Failed to start WiFi connect task.");
    }
}

void VoiceRecognitionApp::finish_wifi_scan(esp_err_t result, std::vector<WifiApInfo> aps)
{
    m_wifi_scan_running = false;
    if (result != ESP_OK) {
        lv_dropdown_set_options(m_wifi_dropdown, "No networks scanned");
        lv_label_set_text_fmt(m_wifi_status_label, "WiFi scan failed: %s", esp_err_to_name(result));
        return;
    }

    m_wifi_aps = aps;
    if (m_wifi_aps.empty()) {
        lv_dropdown_set_options(m_wifi_dropdown, "No networks found");
        lv_label_set_text(m_wifi_status_label, "No WiFi networks found.");
        return;
    }

    std::string options;
    for (size_t i = 0; i < m_wifi_aps.size(); ++i) {
        if (i > 0) {
            options += "\n";
        }
        options += m_wifi_aps[i].ssid;
        options += m_wifi_aps[i].secure ? "  * " : "  open ";
        options += std::to_string(m_wifi_aps[i].rssi);
        options += " dBm";
    }
    lv_dropdown_set_options(m_wifi_dropdown, options.c_str());
    lv_label_set_text_fmt(m_wifi_status_label, "Found %u networks. Choose one and connect.",
                          static_cast<unsigned>(m_wifi_aps.size()));
}

void VoiceRecognitionApp::finish_wifi_connect(esp_err_t result, const std::string &ssid)
{
    m_wifi_connect_running = false;
    if (result == ESP_OK) {
        lv_label_set_text_fmt(m_wifi_status_label, "Connected to %s. Ready for WHIP video publish.", ssid.c_str());
    } else {
        lv_label_set_text_fmt(m_wifi_status_label, "Connect failed: %s", esp_err_to_name(result));
    }
}

void VoiceRecognitionApp::set_status(const char *text)
{
    if (m_status_label) {
        lv_label_set_text(m_status_label, text);
    }
}

void VoiceRecognitionApp::recognition_result_cb(const std::string &result)
{
    m_text_result_lcd_disp->save_text_result(result);
    if (m_screen == Screen::FACE_LOGIN && result.rfind("id:", 0) == 0) {
        m_voice.play_success_prompt();
        bsp_display_lock(0);
        show_screen(Screen::HOME);
        bsp_display_unlock();
    } else if (m_screen == Screen::FACE_LOGIN) {
        trigger_recognition_event(who::recognition::WhoRecognitionCore::RECOGNIZE);
    }
}

void VoiceRecognitionApp::detect_result_cb(const who::detect::WhoDetect::result_t &result)
{
    m_detect_result_lcd_disp->save_detect_result(result);
    if (result.det_res.empty()) {
        return;
    }

    int64_t now = esp_timer_get_time();
    if (now - m_last_face_announce_us > 3000000) {
        m_last_face_announce_us = now;
    }
}

void VoiceRecognitionApp::lcd_disp_cb(who::cam::cam_fb_t *fb)
{
    if (m_screen == Screen::FACE_LOGIN || m_screen == Screen::ENROLL) {
        m_detect_result_lcd_disp->lcd_disp_cb(fb);
        m_text_result_lcd_disp->lcd_disp_cb(fb);
    }
}

void VoiceRecognitionApp::cleanup_recognition_result()
{
    m_text_result_lcd_disp->cleanup();
}

void VoiceRecognitionApp::cleanup_detect_result()
{
    m_detect_result_lcd_disp->cleanup();
}

void VoiceRecognitionApp::trigger_recognition_event(EventBits_t event)
{
    auto task = m_recognition->get_recognition_task();
    if (task && task->is_active()) {
        xEventGroupSetBits(task->get_event_group(), event);
    }
}

void VoiceRecognitionApp::wifi_scan_task(void *arg)
{
    auto *app = static_cast<VoiceRecognitionApp *>(arg);
    std::vector<WifiApInfo> aps;
    esp_err_t result = app->m_wifi.scan(aps);

    bsp_display_lock(0);
    app->finish_wifi_scan(result, aps);
    bsp_display_unlock();
    vTaskDelete(nullptr);
}

void VoiceRecognitionApp::wifi_connect_task(void *arg)
{
    auto *app = static_cast<VoiceRecognitionApp *>(arg);
    std::string ssid = app->m_pending_wifi_ssid;
    std::string password = app->m_pending_wifi_password;
    esp_err_t result = app->m_wifi.connect(ssid, password);

    bsp_display_lock(0);
    app->finish_wifi_connect(result, ssid);
    bsp_display_unlock();
    vTaskDelete(nullptr);
}
