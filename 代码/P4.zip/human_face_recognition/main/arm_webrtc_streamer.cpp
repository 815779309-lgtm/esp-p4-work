#include "arm_webrtc_streamer.hpp"

#include "esp_heap_caps.h"
#include "esp_log.h"
#include "esp_peer_default.h"
#include "esp_timer.h"
#include "esp_video_enc_default.h"
#include "esp_wifi.h"
#include "esp_webrtc_defaults.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include <cstring>

namespace {
constexpr const char *TAG = "ArmWebRTCStreamer";
constexpr const char *WHIP_SERVER = "http://192.168.187.136:8889/push_stream_name/whip";
constexpr const char *WHIP_TOKEN = "zxh:12345678";
constexpr uint8_t STREAM_FPS = 15;
constexpr uint16_t STREAM_MAX_WIDTH = 320;
constexpr uint16_t STREAM_MAX_HEIGHT = 180;
constexpr uint32_t STREAM_VIDEO_BITRATE = 200000;
constexpr int64_t WEBRTC_QUERY_INTERVAL_US = 2000000;
constexpr int64_t WEBRTC_RETRY_INTERVAL_US = 2000000;
constexpr int64_t FRAME_INTERVAL_US = 1000000 / STREAM_FPS;

void *alloc_frame(size_t size)
{
    void *buf = heap_caps_malloc(size, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!buf) {
        buf = heap_caps_malloc(size, MALLOC_CAP_8BIT);
    }
    return buf;
}

bool wifi_connected()
{
    wifi_ap_record_t ap = {};
    return esp_wifi_sta_get_ap_info(&ap) == ESP_OK;
}

void fit_stream_size(uint16_t src_w, uint16_t src_h, uint16_t *dst_w, uint16_t *dst_h)
{
    uint32_t w = src_w;
    uint32_t h = src_h;
    if (w > STREAM_MAX_WIDTH) {
        h = h * STREAM_MAX_WIDTH / w;
        w = STREAM_MAX_WIDTH;
    }
    if (h > STREAM_MAX_HEIGHT) {
        w = w * STREAM_MAX_HEIGHT / h;
        h = STREAM_MAX_HEIGHT;
    }
    *dst_w = static_cast<uint16_t>(w & ~1U);
    *dst_h = static_cast<uint16_t>(h & ~1U);
    if (*dst_w < 2) {
        *dst_w = 2;
    }
    if (*dst_h < 2) {
        *dst_h = 2;
    }
}

void downscale_rgb565(const uint16_t *src, uint16_t src_w, uint16_t src_h, uint16_t *dst, uint16_t dst_w, uint16_t dst_h)
{
    for (uint16_t y = 0; y < dst_h; ++y) {
        uint32_t src_y = static_cast<uint32_t>(y) * src_h / dst_h;
        for (uint16_t x = 0; x < dst_w; ++x) {
            uint32_t src_x = static_cast<uint32_t>(x) * src_w / dst_w;
            dst[static_cast<size_t>(y) * dst_w + x] = src[static_cast<size_t>(src_y) * src_w + src_x];
        }
    }
}

static inline uint8_t clamp_u8(int v)
{
    return static_cast<uint8_t>(v < 0 ? 0 : (v > 255 ? 255 : v));
}

void rgb565_to_yuv(uint16_t p, uint8_t *y, uint8_t *u, uint8_t *v)
{
    uint8_t r = ((p >> 11) & 0x1F) << 3;
    uint8_t g = ((p >> 5) & 0x3F) << 2;
    uint8_t b = (p & 0x1F) << 3;
    *y = clamp_u8(((66 * r + 129 * g + 25 * b + 128) >> 8) + 16);
    *u = clamp_u8(((-38 * r - 74 * g + 112 * b + 128) >> 8) + 128);
    *v = clamp_u8(((112 * r - 94 * g - 18 * b + 128) >> 8) + 128);
}

void rgb565_to_ouyy_evyy(const uint16_t *rgb565, uint16_t width, uint16_t height, uint8_t *dst)
{
    size_t line_stride = static_cast<size_t>(width) * 3 / 2;
    for (uint16_t y = 0; y < height; y += 2) {
        const uint16_t *line0 = rgb565 + static_cast<size_t>(y) * width;
        const uint16_t *line1 = (y + 1 < height) ? (line0 + width) : line0;
        uint8_t *out0 = dst + static_cast<size_t>(y) * line_stride;
        uint8_t *out1 = (y + 1 < height) ? (out0 + line_stride) : out0;

        for (uint16_t x = 0; x < width; x += 2) {
            uint8_t y00, u00, v00;
            uint8_t y01, u01, v01;
            uint8_t y10, u10, v10;
            uint8_t y11, u11, v11;
            rgb565_to_yuv(line0[x], &y00, &u00, &v00);
            rgb565_to_yuv(line0[x + 1], &y01, &u01, &v01);
            rgb565_to_yuv(line1[x], &y10, &u10, &v10);
            rgb565_to_yuv(line1[x + 1], &y11, &u11, &v11);

            uint8_t u = static_cast<uint8_t>((static_cast<uint16_t>(u00) + u01 + u10 + u11) / 4);
            uint8_t v = static_cast<uint8_t>((static_cast<uint16_t>(v00) + v01 + v10 + v11) / 4);
            size_t pos = static_cast<size_t>(x) * 3 / 2;
            out0[pos] = u;
            out0[pos + 1] = y00;
            out0[pos + 2] = y01;
            out1[pos] = v;
            out1[pos + 1] = y10;
            out1[pos + 2] = y11;
        }
    }
}
} // namespace

struct ArmWebRTCStreamer::FrameCapVideoSource {
    esp_capture_video_src_if_t base;
    SemaphoreHandle_t mutex;
    SemaphoreHandle_t frame_ready;
    uint8_t *frame_data[2];
    size_t frame_size[2];
    size_t frame_capacity[2];
    bool frame_in_use[2];
    uint8_t latest_index;
    uint16_t width;
    uint16_t height;
    bool running;
    esp_capture_video_info_t fixed_caps;
};

namespace {
ArmWebRTCStreamer::FrameCapVideoSource *as_source(esp_capture_video_src_if_t *src)
{
    return reinterpret_cast<ArmWebRTCStreamer::FrameCapVideoSource *>(src);
}

esp_capture_err_t src_open(esp_capture_video_src_if_t *src)
{
    auto *s = as_source(src);
    s->running = false;
    s->frame_in_use[0] = false;
    s->frame_in_use[1] = false;
    return ESP_CAPTURE_ERR_OK;
}

esp_capture_err_t src_get_support_codecs(esp_capture_video_src_if_t *, const esp_capture_format_id_t **codecs, uint8_t *num)
{
    static const esp_capture_format_id_t supported[] = {ESP_CAPTURE_FMT_ID_O_UYY_E_VYY};
    *codecs = supported;
    *num = sizeof(supported) / sizeof(supported[0]);
    return ESP_CAPTURE_ERR_OK;
}

esp_capture_err_t src_set_fixed_caps(esp_capture_video_src_if_t *src, const esp_capture_video_info_t *fixed_caps)
{
    auto *s = as_source(src);
    if (!fixed_caps) {
        return ESP_CAPTURE_ERR_INVALID_ARG;
    }
    s->fixed_caps = *fixed_caps;
    return ESP_CAPTURE_ERR_OK;
}

esp_capture_err_t src_negotiate_caps(esp_capture_video_src_if_t *src,
                                     esp_capture_video_info_t *in_caps,
                                     esp_capture_video_info_t *out_caps)
{
    auto *s = as_source(src);
    if (in_caps && in_caps->format_id != ESP_CAPTURE_FMT_ID_ANY &&
        in_caps->format_id != ESP_CAPTURE_FMT_ID_O_UYY_E_VYY) {
        return ESP_CAPTURE_ERR_NOT_SUPPORTED;
    }
    out_caps->format_id = ESP_CAPTURE_FMT_ID_O_UYY_E_VYY;
    out_caps->width = s->fixed_caps.width ? s->fixed_caps.width : s->width;
    out_caps->height = s->fixed_caps.height ? s->fixed_caps.height : s->height;
    out_caps->fps = s->fixed_caps.fps ? s->fixed_caps.fps : STREAM_FPS;
    return ESP_CAPTURE_ERR_OK;
}

esp_capture_err_t src_start(esp_capture_video_src_if_t *src)
{
    auto *s = as_source(src);
    s->running = true;
    s->frame_in_use[0] = false;
    s->frame_in_use[1] = false;
    return ESP_CAPTURE_ERR_OK;
}

esp_capture_err_t src_acquire_frame(esp_capture_video_src_if_t *src, esp_capture_stream_frame_t *frame)
{
    auto *s = as_source(src);
    if (!s->running) {
        return ESP_CAPTURE_ERR_INVALID_STATE;
    }
    if (xSemaphoreTake(s->frame_ready, pdMS_TO_TICKS(200)) != pdTRUE) {
        return ESP_CAPTURE_ERR_TIMEOUT;
    }
    if (!s->running) {
        return ESP_CAPTURE_ERR_INVALID_STATE;
    }
    if (xSemaphoreTake(s->mutex, pdMS_TO_TICKS(200)) != pdTRUE) {
        return ESP_CAPTURE_ERR_TIMEOUT;
    }
    uint8_t index = s->latest_index;
    if (!s->frame_data[index] || s->frame_size[index] == 0) {
        xSemaphoreGive(s->mutex);
        return ESP_CAPTURE_ERR_INVALID_STATE;
    }
    if (s->frame_in_use[index]) {
        xSemaphoreGive(s->mutex);
        return ESP_CAPTURE_ERR_TIMEOUT;
    }
    s->frame_in_use[index] = true;
    frame->stream_type = ESP_CAPTURE_STREAM_TYPE_VIDEO;
    frame->data = s->frame_data[index];
    frame->size = static_cast<int>(s->frame_size[index]);
    frame->pts = static_cast<uint32_t>(esp_timer_get_time() / 1000);
    xSemaphoreGive(s->mutex);
    return ESP_CAPTURE_ERR_OK;
}

esp_capture_err_t src_release_frame(esp_capture_video_src_if_t *src, esp_capture_stream_frame_t *frame)
{
    auto *s = as_source(src);
    if (s && xSemaphoreTake(s->mutex, pdMS_TO_TICKS(200)) == pdTRUE) {
        if (frame && frame->data == s->frame_data[0]) {
            s->frame_in_use[0] = false;
        } else if (frame && frame->data == s->frame_data[1]) {
            s->frame_in_use[1] = false;
        }
        xSemaphoreGive(s->mutex);
    }
    if (frame) {
        frame->data = nullptr;
        frame->size = 0;
    }
    return ESP_CAPTURE_ERR_OK;
}

esp_capture_err_t src_stop(esp_capture_video_src_if_t *src)
{
    auto *s = as_source(src);
    s->running = false;
    s->frame_in_use[0] = false;
    s->frame_in_use[1] = false;
    xSemaphoreGive(s->frame_ready);
    return ESP_CAPTURE_ERR_OK;
}

esp_capture_err_t src_close(esp_capture_video_src_if_t *src)
{
    return src_stop(src);
}
} // namespace

ArmWebRTCStreamer::ArmWebRTCStreamer(const std::string &name,
                                     who::frame_cap::WhoFrameCapNode *frame_cap_node,
                                     int peek_index) :
    who::task::WhoTask(name),
    m_frame_cap_node(frame_cap_node),
    m_peek_index(peek_index),
    m_enabled(false),
    m_publishing(false),
    m_last_start_us(0),
    m_last_frame_us(0),
    m_last_query_us(0),
    m_state_mutex(xSemaphoreCreateMutex()),
    m_video_source(new FrameCapVideoSource{}),
    m_capture(nullptr),
    m_webrtc(nullptr)
{
    m_video_source->base.open = src_open;
    m_video_source->base.get_support_codecs = src_get_support_codecs;
    m_video_source->base.set_fixed_caps = src_set_fixed_caps;
    m_video_source->base.negotiate_caps = src_negotiate_caps;
    m_video_source->base.start = src_start;
    m_video_source->base.acquire_frame = src_acquire_frame;
    m_video_source->base.release_frame = src_release_frame;
    m_video_source->base.stop = src_stop;
    m_video_source->base.close = src_close;
    m_video_source->mutex = xSemaphoreCreateMutex();
    m_video_source->frame_ready = xSemaphoreCreateBinary();
    fit_stream_size(frame_cap_node->get_fb_width(), frame_cap_node->get_fb_height(),
                    &m_video_source->width, &m_video_source->height);
    m_video_source->latest_index = 0;
    size_t initial_capacity = static_cast<size_t>(m_video_source->width) * m_video_source->height * 3 / 2;
    m_video_source->frame_data[0] = static_cast<uint8_t *>(alloc_frame(initial_capacity));
    m_video_source->frame_data[1] = static_cast<uint8_t *>(alloc_frame(initial_capacity));
    m_video_source->frame_capacity[0] = m_video_source->frame_data[0] ? initial_capacity : 0;
    m_video_source->frame_capacity[1] = m_video_source->frame_data[1] ? initial_capacity : 0;
    m_video_source->fixed_caps = {
        .format_id = ESP_CAPTURE_FMT_ID_O_UYY_E_VYY,
        .width = m_video_source->width,
        .height = m_video_source->height,
        .fps = STREAM_FPS,
    };
}

ArmWebRTCStreamer::~ArmWebRTCStreamer()
{
    stop_webrtc();
    if (m_capture) {
        esp_capture_close(m_capture);
        m_capture = nullptr;
    }
    if (m_video_source) {
        for (int i = 0; i < 2; ++i) {
            if (m_video_source->frame_data[i]) {
                heap_caps_free(m_video_source->frame_data[i]);
            }
        }
        if (m_video_source->mutex) {
            vSemaphoreDelete(m_video_source->mutex);
        }
        if (m_video_source->frame_ready) {
            vSemaphoreDelete(m_video_source->frame_ready);
        }
        delete m_video_source;
    }
    if (m_state_mutex) {
        vSemaphoreDelete(m_state_mutex);
    }
}

void ArmWebRTCStreamer::set_enabled(bool enabled)
{
    if (xSemaphoreTake(m_state_mutex, pdMS_TO_TICKS(200)) == pdTRUE) {
        m_enabled = enabled;
        xSemaphoreGive(m_state_mutex);
    }
    xEventGroupSetBits(m_event_group, NEW_FRAME);
}

void ArmWebRTCStreamer::task()
{
    esp_video_enc_register_default();

    while (true) {
        bool enabled = false;
        if (xSemaphoreTake(m_state_mutex, pdMS_TO_TICKS(20)) == pdTRUE) {
            enabled = m_enabled;
            xSemaphoreGive(m_state_mutex);
        }

        TickType_t wait_ticks = enabled ? pdMS_TO_TICKS(1000 / STREAM_FPS) : portMAX_DELAY;
        EventBits_t event_bits =
            xEventGroupWaitBits(m_event_group, NEW_FRAME | TASK_PAUSE | TASK_STOP, pdTRUE, pdFALSE, wait_ticks);
        if (event_bits & TASK_STOP) {
            break;
        } else if (event_bits & TASK_PAUSE) {
            stop_webrtc();
            xEventGroupSetBits(m_event_group, TASK_PAUSED);
            EventBits_t pause_event_bits =
                xEventGroupWaitBits(m_event_group, TASK_RESUME | TASK_STOP, pdTRUE, pdFALSE, portMAX_DELAY);
            if (pause_event_bits & TASK_STOP) {
                break;
            }
            continue;
        }

        if (!enabled) {
            if (m_publishing) {
                stop_webrtc();
            }
            continue;
        }

        update_latest_frame();
        if (!m_publishing) {
            int64_t now = esp_timer_get_time();
            if (now - m_last_start_us >= WEBRTC_RETRY_INTERVAL_US) {
                m_last_start_us = now;
                start_webrtc();
            }
        }
        query_webrtc();
    }

    stop_webrtc();
    xEventGroupSetBits(m_event_group, TASK_STOPPED);
    vTaskDelete(nullptr);
}

bool ArmWebRTCStreamer::update_latest_frame()
{
    int64_t now = esp_timer_get_time();
    if (now - m_last_frame_us < FRAME_INTERVAL_US) {
        return true;
    }

    if (!m_frame_cap_node || !m_video_source) {
        return false;
    }

    auto *fb = m_frame_cap_node->cam_fb_peek(m_peek_index);
    if (!fb || !fb->buf || fb->len == 0) {
        return false;
    }
    if (fb->format != who::cam::cam_fb_fmt_t::CAM_FB_FMT_RGB565) {
        ESP_LOGW(TAG, "Unsupported WHO frame format for WHIP source: %d", static_cast<int>(fb->format));
        return false;
    }

    uint16_t dst_w = 0;
    uint16_t dst_h = 0;
    fit_stream_size(fb->width, fb->height, &dst_w, &dst_h);
    const size_t ouyy_len = static_cast<size_t>(dst_w) * dst_h * 3 / 2;

    const uint16_t *src_rgb565 = static_cast<const uint16_t *>(fb->buf);
    void *scaled_buf = nullptr;
    if (dst_w != fb->width || dst_h != fb->height) {
        const size_t rgb_len = static_cast<size_t>(dst_w) * dst_h * sizeof(uint16_t);
        scaled_buf = alloc_frame(rgb_len);
        if (!scaled_buf) {
            ESP_LOGW(TAG, "Failed to allocate WHIP scaled RGB565 frame: %u bytes", static_cast<unsigned>(rgb_len));
            return false;
        }
        downscale_rgb565(src_rgb565, fb->width, fb->height, static_cast<uint16_t *>(scaled_buf), dst_w, dst_h);
        src_rgb565 = static_cast<const uint16_t *>(scaled_buf);
    }

    if (xSemaphoreTake(m_video_source->mutex, pdMS_TO_TICKS(200)) != pdTRUE) {
        if (scaled_buf) {
            heap_caps_free(scaled_buf);
        }
        return false;
    }

    uint8_t current = m_video_source->latest_index;
    uint8_t target = current;
    if (m_video_source->frame_in_use[target]) {
        target ^= 1;
    }
    if (m_video_source->frame_in_use[target]) {
        xSemaphoreGive(m_video_source->mutex);
        if (scaled_buf) {
            heap_caps_free(scaled_buf);
        }
        return false;
    }
    if (m_video_source->frame_capacity[target] < ouyy_len) {
        uint8_t *new_frame = static_cast<uint8_t *>(alloc_frame(ouyy_len));
        if (!new_frame) {
            xSemaphoreGive(m_video_source->mutex);
            if (scaled_buf) {
                heap_caps_free(scaled_buf);
            }
            ESP_LOGW(TAG, "Failed to allocate WHIP O_UYY_E_VYY frame: %u bytes", static_cast<unsigned>(ouyy_len));
            return false;
        }
        if (m_video_source->frame_data[target]) {
            heap_caps_free(m_video_source->frame_data[target]);
        }
        m_video_source->frame_data[target] = new_frame;
        m_video_source->frame_capacity[target] = ouyy_len;
    }

    rgb565_to_ouyy_evyy(src_rgb565, dst_w, dst_h, m_video_source->frame_data[target]);
    if (scaled_buf) {
        heap_caps_free(scaled_buf);
    }

    m_video_source->frame_size[target] = ouyy_len;
    m_video_source->latest_index = target;
    m_video_source->width = dst_w;
    m_video_source->height = dst_h;
    m_video_source->fixed_caps = {
        .format_id = ESP_CAPTURE_FMT_ID_O_UYY_E_VYY,
        .width = dst_w,
        .height = dst_h,
        .fps = STREAM_FPS,
    };
    xSemaphoreGive(m_video_source->mutex);
    xSemaphoreGive(m_video_source->frame_ready);

    m_last_frame_us = now;
    return true;
}

bool ArmWebRTCStreamer::ensure_capture()
{
    if (m_capture) {
        return true;
    }

    esp_capture_cfg_t capture_cfg = {
        .sync_mode = ESP_CAPTURE_SYNC_MODE_NONE,
        .audio_src = nullptr,
        .video_src = &m_video_source->base,
        .share_overlay = false,
    };
    esp_capture_err_t ret = esp_capture_open(&capture_cfg, &m_capture);
    if (ret != ESP_CAPTURE_ERR_OK) {
        ESP_LOGE(TAG, "esp_capture_open failed: %d", ret);
        m_capture = nullptr;
        return false;
    }
    return true;
}

esp_err_t ArmWebRTCStreamer::start_webrtc()
{
    if (!wifi_connected()) {
        ESP_LOGW(TAG, "WiFi is not connected, WHIP publish is waiting");
        return ESP_ERR_INVALID_STATE;
    }
    if (!ensure_capture()) {
        return ESP_FAIL;
    }

    stop_webrtc();

    esp_peer_default_cfg_t peer_cfg = {
        .ice_use_lite_mode = true,
    };
    esp_peer_signaling_whip_cfg_t whip_cfg = {
        .auth_type = ESP_PEER_SIGNALING_WHIP_AUTH_TYPE_BASIC,
        .token = const_cast<char *>(WHIP_TOKEN),
    };
    esp_webrtc_cfg_t cfg = {
        .signaling_impl = esp_signaling_get_whip_impl(),
        .signaling_cfg = {
            .signal_url = const_cast<char *>(WHIP_SERVER),
            .extra_cfg = &whip_cfg,
            .extra_size = sizeof(whip_cfg),
            .ctx = nullptr,
        },
        .peer_impl = esp_peer_get_default_impl(),
        .peer_cfg = {
            .video_info = {
                .codec = ESP_PEER_VIDEO_CODEC_H264,
                .width = m_video_source->width,
                .height = m_video_source->height,
                .fps = STREAM_FPS,
            },
            .audio_dir = ESP_PEER_MEDIA_DIR_NONE,
            .video_dir = ESP_PEER_MEDIA_DIR_SEND_ONLY,
            .no_auto_reconnect = true,
            .extra_cfg = &peer_cfg,
            .extra_size = sizeof(peer_cfg),
        },
    };

    ESP_LOGI(TAG, "Free memory before esp_webrtc_open: internal=%d, PSRAM=%d, largest_internal=%d, largest_psram=%d",
             heap_caps_get_free_size(MALLOC_CAP_INTERNAL),
             heap_caps_get_free_size(MALLOC_CAP_SPIRAM),
             heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL),
             heap_caps_get_largest_free_block(MALLOC_CAP_SPIRAM));

    int ret = esp_webrtc_open(&cfg, &m_webrtc);
    if (ret != 0 || !m_webrtc) {
        ESP_LOGE(TAG, "esp_webrtc_open failed: %d (internal=%d, PSRAM=%d)", ret,
                 heap_caps_get_free_size(MALLOC_CAP_INTERNAL),
                 heap_caps_get_free_size(MALLOC_CAP_SPIRAM));
        m_webrtc = nullptr;
        return ESP_FAIL;
    }

    esp_webrtc_media_provider_t provider = {
        .capture = m_capture,
        .player = nullptr,
    };
    esp_webrtc_set_media_provider(m_webrtc, &provider);
    esp_webrtc_set_event_handler(m_webrtc, webrtc_event_handler, this);
    esp_webrtc_set_video_bitrate(m_webrtc, STREAM_VIDEO_BITRATE);
    esp_webrtc_enable_peer_connection(m_webrtc, true);

    ret = esp_webrtc_start(m_webrtc);
    if (ret != 0) {
        ESP_LOGE(TAG, "esp_webrtc_start failed: %d", ret);
        stop_webrtc();
        return ESP_FAIL;
    }

    m_publishing = true;
    m_last_query_us = esp_timer_get_time();
    ESP_LOGI(TAG, "WHIP publish started: %s (%ux%u@%u, bitrate=%u)",
             WHIP_SERVER,
             static_cast<unsigned>(m_video_source->width),
             static_cast<unsigned>(m_video_source->height),
             static_cast<unsigned>(STREAM_FPS),
             static_cast<unsigned>(STREAM_VIDEO_BITRATE));
    return ESP_OK;
}

void ArmWebRTCStreamer::stop_webrtc()
{
    if (m_webrtc) {
        esp_webrtc_handle_t handle = m_webrtc;
        m_webrtc = nullptr;
        m_publishing = false;
        ESP_LOGI(TAG, "Stopping WHIP publish");
        esp_webrtc_close(handle);
    }
}

void ArmWebRTCStreamer::query_webrtc()
{
    if (!m_webrtc) {
        return;
    }
    int64_t now = esp_timer_get_time();
    if (now - m_last_query_us >= WEBRTC_QUERY_INTERVAL_US) {
        esp_webrtc_query(m_webrtc);
        m_last_query_us = now;
    }
}

int ArmWebRTCStreamer::webrtc_event_handler(esp_webrtc_event_t *event, void *)
{
    if (!event) {
        return 0;
    }
    ESP_LOGI(TAG, "WebRTC event: %d", static_cast<int>(event->type));
    return 0;
}
