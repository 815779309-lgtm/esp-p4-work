#pragma once

#include "who_frame_cap_node.hpp"
#include "who_task.hpp"

#include "esp_err.h"
#include "freertos/semphr.h"

#include <cstddef>
#include <cstdint>

struct httpd_req;
typedef struct httpd_req httpd_req_t;

class CameraUploader : public who::task::WhoTask {
public:
    static inline constexpr EventBits_t NEW_FRAME = who::frame_cap::WhoFrameCapNode::NEW_FRAME;

    CameraUploader(const std::string &name, who::frame_cap::WhoFrameCapNode *frame_cap_node, int peek_index = -1);
    void set_enabled(bool enabled);

private:
    void task() override;
    esp_err_t start_http_server();
    void stop_http_server();
    esp_err_t update_latest_frame(const who::cam::cam_fb_t *fb);
    esp_err_t prepare_frame_for_upload(const who::cam::cam_fb_t *src, who::cam::cam_fb_t *dst, void **prepared_buf);
    esp_err_t downscale_rgb565(const who::cam::cam_fb_t *src, who::cam::cam_fb_t *dst, void **scaled_buf);
    esp_err_t encode_frame_to_jpeg(const who::cam::cam_fb_t *src, who::cam::cam_fb_t *dst, void **jpeg_buf);
    static esp_err_t root_handler(httpd_req_t *req);
    static esp_err_t stream_handler(httpd_req_t *req);
    static esp_err_t snapshot_handler(httpd_req_t *req);
    static esp_err_t status_handler(httpd_req_t *req);

    who::frame_cap::WhoFrameCapNode *m_frame_cap_node;
    int m_peek_index;
    bool m_enabled;
    int64_t m_last_upload_us;
    void *m_httpd;
    SemaphoreHandle_t m_frame_mutex;
    uint8_t *m_latest_frame;
    size_t m_latest_frame_len;
    uint16_t m_latest_width;
    uint16_t m_latest_height;
    uint32_t m_frame_seq;
};
