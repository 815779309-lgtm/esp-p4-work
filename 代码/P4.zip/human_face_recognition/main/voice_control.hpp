#pragma once

#include <cstdint>
#include <functional>

#include "freertos/FreeRTOS.h"
#include "freertos/event_groups.h"
#include "freertos/queue.h"

class VoiceControl {
public:
    using CommandCallback = std::function<void(EventBits_t)>;

    VoiceControl();
    bool start(const CommandCallback &command_cb);
    void stop();
    void speak(const char *text);
    void play_success_prompt();
    bool is_started() const;

private:
    enum class Prompt : uint8_t {
        WAKE,
        ENROLL,
        RECOGNIZE,
        SUCCESS,
    };

    static void feed_task(void *arg);
    static void detect_task(void *arg);
    static void prompt_task(void *arg);

    void feed_loop();
    void detect_loop();
    void prompt_loop();
    bool init_audio();
    bool init_sr();
    bool init_tts();
    void post_prompt(Prompt prompt);
    void play_wake_prompt();
    void play_embedded_wav(const uint8_t *start, const uint8_t *end, const char *name);
    void speak_pinyin(const char *pinyin);
    void beep(int frequency_hz, int duration_ms);
    void dispatch_command(int command_id);

    CommandCallback m_command_cb;
    bool m_started;
    bool m_awake;
    int64_t m_command_deadline_us;
    QueueHandle_t m_prompt_queue;
    volatile bool m_speaking;
    volatile bool m_stop_requested;
    TaskHandle_t m_feed_task_handle;
    TaskHandle_t m_detect_task_handle;
    TaskHandle_t m_prompt_task_handle;
};
