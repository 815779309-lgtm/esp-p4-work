#pragma once

#include "esp_err.h"

#include <string>
#include <vector>

struct WifiApInfo {
    std::string ssid;
    int rssi;
    int channel;
    bool secure;
};

class WifiManager {
public:
    WifiManager();

    bool is_supported() const;
    esp_err_t init();
    esp_err_t scan(std::vector<WifiApInfo> &aps);
    esp_err_t connect(const std::string &ssid, const std::string &password);

private:
    bool m_initialized;
    bool m_netif_initialized;
    bool m_event_handlers_registered;
};
