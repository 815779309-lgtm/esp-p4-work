﻿#include "voice_control.hpp"

#include <cstddef>
#include <cstring>
#include <inttypes.h>

#include "bsp/esp-bsp.h"
#include "esp_check.h"
#include "esp_codec_dev.h"
#include "esp_codec_dev_types.h"
#include "esp_heap_caps.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "esp_mn_iface.h"
#include "esp_mn_models.h"
#include "esp_mn_speech_commands.h"
#include "esp_tts.h"
#include "esp_tts_voice_xiaole.h"
#include "esp_afe_sr_iface.h"
#include "esp_afe_sr_models.h"
#include "model_path.h"
#include "who_recognition.hpp"

namespace {
constexpr int kCmdEnroll = 1;
constexpr int kCmdRecognize = 2;
constexpr int kAudioSampleRate = 16000;
constexpr int kAudioChannels = 1;
constexpr int kAudioBits = 16;
constexpr int kTtsSpeed = 4;
constexpr uint32_t kFeedTaskStack = 6144;
constexpr uint32_t kDetectTaskStack = 12288;
constexpr uint32_t kPromptTaskStack = 24576;
constexpr int64_t kCommandListenTimeoutUs = 10000000;

const char *TAG = "VoiceControl";

esp_codec_dev_handle_t s_spk = nullptr;
esp_codec_dev_handle_t s_mic = nullptr;
esp_tts_handle_t s_tts = nullptr;
srmodel_list_t *s_models = nullptr;
const esp_afe_sr_iface_t *s_afe = nullptr;
esp_afe_sr_data_t *s_afe_data = nullptr;
esp_mn_iface_t *s_multinet = nullptr;
model_iface_data_t *s_mn_data = nullptr;

extern const uint8_t wake_wav_start[] asm("_binary_wake_wav_start");
extern const uint8_t wake_wav_end[] asm("_binary_wake_wav_end");
extern const uint8_t success_wav_start[] asm("_binary_success_wav_start");
extern const uint8_t success_wav_end[] asm("_binary_success_wav_end");

struct WavData {
    const uint8_t *data;
    size_t size;
    uint16_t audio_format;
    uint16_t channels;
    uint32_t sample_rate;
    uint16_t bits_per_sample;
};

uint16_t read_le16(const uint8_t *p)
{
    return static_cast<uint16_t>(p[0]) | (static_cast<uint16_t>(p[1]) << 8);
}

uint32_t read_le32(const uint8_t *p)
{
    return static_cast<uint32_t>(p[0]) | (static_cast<uint32_t>(p[1]) << 8) |
           (static_cast<uint32_t>(p[2]) << 16) | (static_cast<uint32_t>(p[3]) << 24);
}

bool find_wav_data(const uint8_t *start, const uint8_t *end, WavData *out)
{
    if (!start || !end || !out || end <= start || static_cast<size_t>(end - start) < 12) {
        return false;
    }
    if (std::memcmp(start, "RIFF", 4) != 0 || std::memcmp(start + 8, "WAVE", 4) != 0) {
        return false;
    }

    WavData info = {};
    const uint8_t *p = start + 12;
    while (p + 8 <= end) {
        const uint8_t *chunk_id = p;
        uint32_t chunk_size = read_le32(p + 4);
        const uint8_t *chunk = p + 8;
        if (chunk > end || chunk_size > static_cast<uint32_t>(end - chunk)) {
            return false;
        }

        if (std::memcmp(chunk_id, "fmt ", 4) == 0 && chunk_size >= 16) {
            info.audio_format = read_le16(chunk);
            info.channels = read_le16(chunk + 2);
            info.sample_rate = read_le32(chunk + 4);
            info.bits_per_sample = read_le16(chunk + 14);
        } else if (std::memcmp(chunk_id, "data", 4) == 0) {
            info.data = chunk;
            info.size = chunk_size;
        }

        p = chunk + chunk_size + (chunk_size & 1);
    }

    if (!info.data || info.size == 0 || info.audio_format != 1 || info.channels != 1 ||
        info.sample_rate == 0 ||
        info.bits_per_sample != kAudioBits) {
        return false;
    }

    *out = info;
    return true;
}

void add_command(int command_id, const char *label, const char *phonemes)
{
    ESP_ERROR_CHECK(esp_mn_commands_phoneme_add(command_id, label, phonemes));
}

void set_wakenet_enabled(bool enabled)
{
    if (!s_afe || !s_afe_data) {
        return;
    }
    if (enabled && s_afe->enable_wakenet) {
        s_afe->enable_wakenet(s_afe_data);
    } else if (!enabled && s_afe->disable_wakenet) {
        s_afe->disable_wakenet(s_afe_data);
    }
}

i2s_std_config_t make_i2s_config(int sample_rate)
{
    i2s_std_config_t cfg = {
        .clk_cfg = I2S_STD_CLK_DEFAULT_CONFIG(static_cast<uint32_t>(sample_rate)),
        .slot_cfg = I2S_STD_PHILIP_SLOT_DEFAULT_CONFIG(I2S_DATA_BIT_WIDTH_16BIT, I2S_SLOT_MODE_MONO),
        .gpio_cfg = {
            .mclk = BSP_I2S_MCLK,
            .bclk = BSP_I2S_SCLK,
            .ws = BSP_I2S_LCLK,
            .dout = BSP_I2S_DOUT,
            .din = BSP_I2S_DSIN,
            .invert_flags = {
                .mclk_inv = false,
                .bclk_inv = false,
                .ws_inv = false,
            },
        },
    };
    return cfg;
}
} // namespace

VoiceControl::VoiceControl() :
    m_started(false),
    m_awake(false),
    m_command_deadline_us(0),
    m_prompt_queue(nullptr),
    m_speaking(false),
    m_stop_requested(false),
    m_feed_task_handle(nullptr),
    m_detect_task_handle(nullptr),
    m_prompt_task_handle(nullptr)
{
}

bool VoiceControl::start(const CommandCallback &command_cb)
{
    m_command_cb = command_cb;
    if (m_started) {
        return true;
    }
    m_stop_requested = false;

    if (!init_audio() || !init_tts()) {
        ESP_LOGE(TAG, "voice playback init failed");
        return false;
    }

    m_started = true;
    return true;
}

void VoiceControl::stop()
{
    if (!m_started) {
        return;
    }
    m_stop_requested = true;
    m_awake = false;
    m_command_deadline_us = 0;
    m_started = false;
    m_speaking = false;
}

void VoiceControl::speak(const char *text)
{
    if (!text || !text[0]) {
        return;
    }

    speak_pinyin(text);
}

void VoiceControl::play_success_prompt()
{
    play_embedded_wav(success_wav_start, success_wav_end, "success.wav");
}

void VoiceControl::speak_pinyin(const char *pinyin)
{
    if (!s_spk || !s_tts || !pinyin || !pinyin[0]) {
        return;
    }

    m_speaking = true;
    set_wakenet_enabled(false);
    esp_tts_stream_reset(s_tts);
    if (esp_tts_parse_pinyin(s_tts, pinyin)) {
        int len = 0;
        do {
            short *data = esp_tts_stream_play(s_tts, &len, kTtsSpeed);
            if (data && len > 0) {
                esp_codec_dev_write(s_spk, data, len * sizeof(short));
            }
        } while (len > 0);
    }
    esp_tts_stream_reset(s_tts);
    if (s_afe && s_afe_data && s_afe->reset_buffer) {
        s_afe->reset_buffer(s_afe_data);
    }
    set_wakenet_enabled(true);
    m_speaking = false;
}

void VoiceControl::play_wake_prompt()
{
    play_embedded_wav(wake_wav_start, wake_wav_end, "wake.wav");
}

void VoiceControl::play_embedded_wav(const uint8_t *start, const uint8_t *end, const char *name)
{
    if (!s_spk) {
        return;
    }

    WavData wav = {};
    if (!find_wav_data(start, end, &wav)) {
        ESP_LOGE(TAG, "%s must be 16-bit PCM, mono", name);
        return;
    }

    m_speaking = true;
    set_wakenet_enabled(false);

    if (wav.sample_rate == kAudioSampleRate) {
        constexpr size_t kChunkBytes = 2048;
        size_t offset = 0;
        while (offset < wav.size) {
            size_t len = wav.size - offset;
            if (len > kChunkBytes) {
                len = kChunkBytes;
            }
            esp_codec_dev_write(s_spk, const_cast<uint8_t *>(wav.data + offset), len);
            offset += len;
        }
    } else {
        ESP_LOGW(TAG, "resampling %s from %" PRIu32 " Hz to %d Hz", name, wav.sample_rate, kAudioSampleRate);
        const int16_t *in = reinterpret_cast<const int16_t *>(wav.data);
        const size_t in_samples = wav.size / sizeof(int16_t);
        const size_t out_samples = in_samples * kAudioSampleRate / wav.sample_rate;
        constexpr size_t kOutChunkSamples = 512;
        int16_t out[kOutChunkSamples];
        size_t out_index = 0;
        while (out_index < out_samples) {
            size_t chunk = out_samples - out_index;
            if (chunk > kOutChunkSamples) {
                chunk = kOutChunkSamples;
            }
            for (size_t i = 0; i < chunk; i++) {
                uint64_t src_q16 = (static_cast<uint64_t>(out_index + i) * wav.sample_rate << 16) / kAudioSampleRate;
                size_t src_index = static_cast<size_t>(src_q16 >> 16);
                uint32_t frac = static_cast<uint32_t>(src_q16 & 0xffff);
                if (src_index + 1 >= in_samples) {
                    out[i] = in[in_samples - 1];
                } else {
                    int32_t s0 = in[src_index];
                    int32_t s1 = in[src_index + 1];
                    out[i] = static_cast<int16_t>(s0 + (((s1 - s0) * static_cast<int32_t>(frac)) >> 16));
                }
            }
            esp_codec_dev_write(s_spk, out, chunk * sizeof(out[0]));
            out_index += chunk;
        }
    }

    if (s_afe && s_afe_data && s_afe->reset_buffer) {
        s_afe->reset_buffer(s_afe_data);
    }
    set_wakenet_enabled(true);
    m_speaking = false;
}

void VoiceControl::beep(int frequency_hz, int duration_ms)
{
    if (!s_spk || frequency_hz <= 0 || duration_ms <= 0) {
        return;
    }

    constexpr int kSamplesPerChunk = 160;
    int16_t samples[kSamplesPerChunk];
    const int total_samples = kAudioSampleRate * duration_ms / 1000;
    const int half_period = kAudioSampleRate / (frequency_hz * 2);
    int written = 0;

    m_speaking = true;
    while (written < total_samples) {
        int chunk = total_samples - written;
        if (chunk > kSamplesPerChunk) {
            chunk = kSamplesPerChunk;
        }
        for (int i = 0; i < chunk; i++) {
            int phase = ((written + i) / half_period) & 1;
            samples[i] = phase ? 2500 : -2500;
        }
        esp_codec_dev_write(s_spk, samples, chunk * sizeof(samples[0]));
        written += chunk;
    }
    m_speaking = false;
}

bool VoiceControl::is_started() const
{
    return m_started;
}

bool VoiceControl::init_audio()
{
#if BSP_CAPS_AUDIO
    if (s_spk) {
        return true;
    }
    i2s_std_config_t i2s_cfg = make_i2s_config(kAudioSampleRate);
    esp_err_t err = bsp_audio_init(&i2s_cfg);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "bsp_audio_init failed: %s", esp_err_to_name(err));
        return false;
    }

    s_spk = bsp_audio_codec_speaker_init();
    ESP_RETURN_ON_FALSE(s_spk, false, TAG, "speaker codec init failed");

    esp_codec_dev_sample_info_t fs = {
        .bits_per_sample = kAudioBits,
        .channel = kAudioChannels,
        .sample_rate = kAudioSampleRate,
    };
    if (esp_codec_dev_set_out_vol(s_spk, 70) != ESP_CODEC_DEV_OK) {
        ESP_LOGE(TAG, "set speaker volume failed");
        return false;
    }
    if (esp_codec_dev_open(s_spk, &fs) != ESP_CODEC_DEV_OK) {
        ESP_LOGE(TAG, "open speaker failed");
        return false;
    }
    return true;
#else
    ESP_LOGE(TAG, "audio is not supported by this BSP");
    return false;
#endif
}

bool VoiceControl::init_sr()
{
    if (s_afe && s_afe_data && s_multinet && s_mn_data) {
        return true;
    }
    s_models = esp_srmodel_init("model");
    ESP_RETURN_ON_FALSE(s_models, false, TAG, "failed to load SR models from model partition");

    afe_config_t *afe_config = afe_config_init("M", s_models, AFE_TYPE_SR, AFE_MODE_LOW_COST);
    ESP_RETURN_ON_FALSE(afe_config, false, TAG, "afe_config_init failed");
    afe_config->wakenet_init = true;
    afe_config->vad_init = true;
    afe_config->pcm_config.mic_num = 1;
    afe_config->pcm_config.ref_num = 0;
    afe_config->pcm_config.total_ch_num = 1;

    s_afe = esp_afe_handle_from_config(afe_config);
    s_afe_data = s_afe->create_from_config(afe_config);
    afe_config_free(afe_config);
    ESP_RETURN_ON_FALSE(s_afe && s_afe_data, false, TAG, "AFE init failed");

    char *mn_name = esp_srmodel_filter(s_models, ESP_MN_PREFIX, ESP_MN_CHINESE);
    ESP_RETURN_ON_FALSE(mn_name, false, TAG, "Chinese MultiNet model not found");

    s_multinet = esp_mn_handle_from_name(mn_name);
    s_mn_data = s_multinet->create(mn_name, 5760);
    ESP_RETURN_ON_FALSE(s_multinet && s_mn_data, false, TAG, "MultiNet init failed");
    if (s_multinet->set_det_threshold) {
        s_multinet->set_det_threshold(s_mn_data, 0.35f);
    }

    esp_mn_commands_alloc(s_multinet, s_mn_data);
    add_command(kCmdEnroll, "ren lian lu ru", "ren lian lu ru");
    add_command(kCmdEnroll, "lu ru ren lian", "lu ru ren lian");
    add_command(kCmdEnroll, "kai shi lu ru", "kai shi lu ru");
    add_command(kCmdEnroll, "kai shi ren lian lu ru", "kai shi ren lian lu ru");
    add_command(kCmdEnroll, "wo yao lu ru", "wo yao lu ru");
    add_command(kCmdRecognize, "ren lian shi bie", "ren lian shi bie");
    add_command(kCmdRecognize, "shi bie ren lian", "shi bie ren lian");
    add_command(kCmdRecognize, "kai shi shi bie", "kai shi shi bie");
    add_command(kCmdRecognize, "kai shi ren lian shi bie", "kai shi ren lian shi bie");
    add_command(kCmdRecognize, "wo yao shi bie", "wo yao shi bie");
    add_command(kCmdRecognize, "da kai kong tiao", "da kai kong tiao");
    esp_mn_error_t *err = esp_mn_commands_update();
    if (err) {
        ESP_LOGE(TAG, "failed to update speech commands");
        return false;
    }
    if (s_multinet->open_log) {
        s_multinet->open_log(s_mn_data);
    }
    esp_mn_active_commands_print();
    return true;
}

bool VoiceControl::init_tts()
{
    if (s_tts) {
        return true;
    }
    s_tts = esp_tts_create((esp_tts_voice_t*)&esp_tts_voice_xiaole);
    ESP_RETURN_ON_FALSE(s_tts, false, TAG, "TTS init failed");
    return true;
}

void VoiceControl::feed_task(void *arg)
{
    static_cast<VoiceControl *>(arg)->feed_loop();
}

void VoiceControl::detect_task(void *arg)
{
    static_cast<VoiceControl *>(arg)->detect_loop();
}

void VoiceControl::prompt_task(void *arg)
{
    static_cast<VoiceControl *>(arg)->prompt_loop();
}

void VoiceControl::post_prompt(Prompt prompt)
{
    if (m_prompt_queue) {
        xQueueSend(m_prompt_queue, &prompt, 0);
    }
}

void VoiceControl::prompt_loop()
{
    Prompt prompt;
    while (!m_stop_requested) {
        if (xQueueReceive(m_prompt_queue, &prompt, pdMS_TO_TICKS(100)) != pdTRUE) {
            continue;
        }
        if (m_stop_requested) {
            break;
        }

        switch (prompt) {
        case Prompt::WAKE:
            play_wake_prompt();
            s_multinet->clean(s_mn_data);
            set_wakenet_enabled(true);
            m_command_deadline_us = esp_timer_get_time() + kCommandListenTimeoutUs;
            ESP_LOGI(TAG, "voice command listening: say 'ren lian lu ru', 'ren lian shi bie', or 'da kai kong tiao'");
            break;
        case Prompt::ENROLL:
            speak_pinyin("kai1 shi3 lu4 ru4 ren2 lian3");
            break;
        case Prompt::RECOGNIZE:
            speak_pinyin("kai1 shi3 ren2 lian3 shi2 bie2");
            break;
        case Prompt::SUCCESS:
            play_embedded_wav(success_wav_start, success_wav_end, "success.wav");
            break;
        }
    }
    m_prompt_task_handle = nullptr;
    vTaskDelete(nullptr);
}

void VoiceControl::feed_loop()
{
    const int chunksize = s_afe->get_feed_chunksize(s_afe_data);
    const int channels = s_afe->get_feed_channel_num(s_afe_data);
    const size_t bytes = chunksize * channels * sizeof(int16_t);
    int16_t *buffer = static_cast<int16_t *>(heap_caps_malloc(bytes, MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT));
    if (!buffer) {
        ESP_LOGE(TAG, "failed to allocate feed buffer");
        m_feed_task_handle = nullptr;
        vTaskDelete(nullptr);
        return;
    }

    while (!m_stop_requested) {
        int ret = esp_codec_dev_read(s_mic, buffer, bytes);
        if (ret == ESP_CODEC_DEV_OK) {
            s_afe->feed(s_afe_data, buffer);
        } else {
            ESP_LOGW(TAG, "microphone read failed: %d", ret);
            vTaskDelay(pdMS_TO_TICKS(20));
        }
    }
    heap_caps_free(buffer);
    m_feed_task_handle = nullptr;
    vTaskDelete(nullptr);
}

void VoiceControl::detect_loop()
{
    const int afe_chunksize = s_afe->get_fetch_chunksize(s_afe_data);
    const int mn_chunksize = s_multinet->get_samp_chunksize(s_mn_data);
    int64_t last_listen_log_us = 0;
    if (afe_chunksize != mn_chunksize) {
        ESP_LOGW(TAG, "AFE chunksize %d differs from MultiNet chunksize %d", afe_chunksize, mn_chunksize);
    }

    while (!m_stop_requested) {
        afe_fetch_result_t *res = s_afe->fetch(s_afe_data);
        if (!res || res->ret_value == ESP_FAIL) {
            vTaskDelay(pdMS_TO_TICKS(20));
            continue;
        }

        if (m_speaking) {
            continue;
        }

        int64_t now = esp_timer_get_time();
        if (res->wakeup_state == WAKENET_DETECTED) {
            ESP_LOGI(TAG,
                     "wake word detected: model=%d word=%d",
                     res->wakenet_model_index,
                     res->wake_word_index);
            m_awake = true;
            post_prompt(Prompt::WAKE);
            m_command_deadline_us = 0;
            s_multinet->clean(s_mn_data);
            continue;
        }

        if (!m_awake) {
            continue;
        }

        if (m_command_deadline_us == 0) {
            continue;
        }

        if (now - last_listen_log_us > 1000000) {
            last_listen_log_us = now;
            ESP_LOGI(TAG, "listening audio: volume=%.1f vad=%d", res->data_volume, static_cast<int>(res->vad_state));
        }

        if (now > m_command_deadline_us) {
            ESP_LOGI(TAG, "voice command listen timeout");
            m_awake = false;
            set_wakenet_enabled(true);
            s_multinet->clean(s_mn_data);
            continue;
        }

        esp_mn_state_t mn_state = s_multinet->detect(s_mn_data, res->data);
        if (mn_state == ESP_MN_STATE_DETECTED) {
            esp_mn_results_t *mn_result = s_multinet->get_results(s_mn_data);
            if (mn_result && mn_result->num > 0) {
                ESP_LOGI(TAG,
                         "voice command detected: id=%d text=%s raw=%s prob=%.3f",
                         mn_result->command_id[0],
                         mn_result->string,
                         mn_result->raw_string,
                         mn_result->prob[0]);
                dispatch_command(mn_result->command_id[0]);
            } else if (mn_result) {
                ESP_LOGW(TAG, "voice detected but no command matched: raw=%s", mn_result->raw_string);
            }
            m_awake = false;
            set_wakenet_enabled(true);
            s_multinet->clean(s_mn_data);
        } else if (mn_state == ESP_MN_STATE_TIMEOUT) {
            ESP_LOGI(TAG, "multinet command timeout");
            m_awake = false;
            set_wakenet_enabled(true);
            s_multinet->clean(s_mn_data);
        }
    }
    m_detect_task_handle = nullptr;
    vTaskDelete(nullptr);
}

void VoiceControl::dispatch_command(int command_id)
{
    if (!m_command_cb) {
        return;
    }

    if (command_id == kCmdEnroll) {
        post_prompt(Prompt::ENROLL);
        m_command_cb(who::recognition::WhoRecognitionCore::ENROLL);
    } else if (command_id == kCmdRecognize) {
        post_prompt(Prompt::RECOGNIZE);
        m_command_cb(who::recognition::WhoRecognitionCore::RECOGNIZE);
    }
}
