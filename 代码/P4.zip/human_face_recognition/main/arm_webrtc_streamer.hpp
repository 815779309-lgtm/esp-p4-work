#pragma once

#include "who_frame_cap_node.hpp"
#include "who_task.hpp"

#include "esp_capture.h"
#include "esp_err.h"
#include "esp_webrtc.h"
#include "freertos/semphr.h"

#include <cstddef>
#include <cstdint>
#include <string>

class ArmWebRTCStreamer : public who::task::WhoTask {
public:
    static inline constexpr EventBits_t NEW_FRAME = who::frame_cap::WhoFrameCapNode::NEW_FRAME;
    struct FrameCapVideoSource;

    ArmWebRTCStreamer(const std::string &name, who::frame_cap::WhoFrameCapNode *frame_cap_node, int peek_index = -1);
    ~ArmWebRTCStreamer();

    void set_enabled(bool enabled);

private:
    void task() override;
    bool ensure_capture();
    esp_err_t start_webrtc();
    void stop_webrtc();
    void query_webrtc();
    bool update_latest_frame();
    static int webrtc_event_handler(esp_webrtc_event_t *event, void *ctx);

    who::frame_cap::WhoFrameCapNode *m_frame_cap_node;
    int m_peek_index;
    bool m_enabled;
    bool m_publishing;
    int64_t m_last_start_us;
    int64_t m_last_frame_us;
    int64_t m_last_query_us;
    SemaphoreHandle_t m_state_mutex;
    FrameCapVideoSource *m_video_source;
    esp_capture_handle_t m_capture;
    esp_webrtc_handle_t m_webrtc;
};
