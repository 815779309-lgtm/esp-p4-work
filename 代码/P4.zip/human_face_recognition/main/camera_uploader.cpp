#include "camera_uploader.hpp"

#include "esp_heap_caps.h"
#include "esp_http_server.h"
#include "esp_jpeg_enc.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include <cstdio>
#include <cstring>

namespace {
constexpr const char *TAG = "CameraUploader";
constexpr int64_t FRAME_UPDATE_INTERVAL_US = 200000;
constexpr uint16_t HTTP_PORT = 8080;
constexpr int STREAM_DELAY_MS = 100;
constexpr uint8_t JPEG_QUALITY = 15;
constexpr uint16_t UPLOAD_MAX_WIDTH = 640;
constexpr uint16_t UPLOAD_MAX_HEIGHT = 480;

const char *frame_format_name(who::cam::cam_fb_fmt_t format)
{
    switch (format) {
    case who::cam::cam_fb_fmt_t::CAM_FB_FMT_RGB565:
        return "RGB565";
    case who::cam::cam_fb_fmt_t::CAM_FB_FMT_RGB888:
        return "RGB888";
    case who::cam::cam_fb_fmt_t::CAM_FB_FMT_JPEG:
        return "JPEG";
    default:
        return "UNKNOWN";
    }
}
} // namespace

CameraUploader::CameraUploader(const std::string &name, who::frame_cap::WhoFrameCapNode *frame_cap_node, int peek_index) :
    who::task::WhoTask(name),
    m_frame_cap_node(frame_cap_node),
    m_peek_index(peek_index),
    m_enabled(false),
    m_last_upload_us(0),
    m_httpd(nullptr),
    m_frame_mutex(xSemaphoreCreateMutex()),
    m_latest_frame(nullptr),
    m_latest_frame_len(0),
    m_latest_width(0),
    m_latest_height(0),
    m_frame_seq(0)
{
    m_frame_cap_node->add_new_frame_signal_subscriber(this);
}

void CameraUploader::set_enabled(bool enabled)
{
    m_enabled = enabled;
    if (enabled) {
        m_last_upload_us = 0;
    }
}

void CameraUploader::task()
{
    esp_err_t server_err = start_http_server();
    if (server_err != ESP_OK) {
        ESP_LOGW(TAG, "failed to start MJPEG server: %s", esp_err_to_name(server_err));
    }

    while (true) {
        EventBits_t event_bits =
            xEventGroupWaitBits(m_event_group, NEW_FRAME | TASK_PAUSE | TASK_STOP, pdTRUE, pdFALSE, portMAX_DELAY);
        if (event_bits & TASK_STOP) {
            break;
        } else if (event_bits & TASK_PAUSE) {
            xEventGroupSetBits(m_event_group, TASK_PAUSED);
            EventBits_t pause_event_bits =
                xEventGroupWaitBits(m_event_group, TASK_RESUME | TASK_STOP, pdTRUE, pdFALSE, portMAX_DELAY);
            if (pause_event_bits & TASK_STOP) {
                break;
            }
            continue;
        }

        if (!m_enabled) {
            continue;
        }

        int64_t now = esp_timer_get_time();
        if (now - m_last_upload_us < FRAME_UPDATE_INTERVAL_US) {
            continue;
        }
        auto *fb = m_frame_cap_node->cam_fb_peek(m_peek_index);
        if (!fb || !fb->buf || fb->len == 0) {
            continue;
        }

        void *prepared_buf = nullptr;
        who::cam::cam_fb_t upload_fb = {};
        esp_err_t err = prepare_frame_for_upload(fb, &upload_fb, &prepared_buf);
        if (err != ESP_OK) {
            ESP_LOGW(TAG, "failed to prepare frame for upload: %s", esp_err_to_name(err));
            continue;
        }

        void *jpeg_buf = nullptr;
        who::cam::cam_fb_t jpeg_fb = {};
        err = encode_frame_to_jpeg(&upload_fb, &jpeg_fb, &jpeg_buf);
        if (err == ESP_OK) {
            err = update_latest_frame(&jpeg_fb);
        }
        if (err != ESP_OK) {
            ESP_LOGW(TAG, "frame update failed: %s", esp_err_to_name(err));
        }
        if (jpeg_buf) {
            heap_caps_free(jpeg_buf);
        }
        if (prepared_buf) {
            heap_caps_free(prepared_buf);
        }
        m_last_upload_us = esp_timer_get_time();
    }

    stop_http_server();
    xEventGroupSetBits(m_event_group, TASK_STOPPED);
    vTaskDelete(nullptr);
}

esp_err_t CameraUploader::start_http_server()
{
    if (m_httpd) {
        return ESP_OK;
    }

    httpd_config_t config = HTTPD_DEFAULT_CONFIG();
    config.server_port = HTTP_PORT;
    config.ctrl_port = HTTP_PORT + 1;
    config.max_uri_handlers = 4;
    config.stack_size = 8192;

    esp_err_t err = httpd_start(&m_httpd, &config);
    if (err != ESP_OK) {
        m_httpd = nullptr;
        return err;
    }

    httpd_uri_t root = {
        .uri = "/",
        .method = HTTP_GET,
        .handler = root_handler,
        .user_ctx = this,
    };
    httpd_uri_t stream = {
        .uri = "/stream",
        .method = HTTP_GET,
        .handler = stream_handler,
        .user_ctx = this,
    };
    httpd_uri_t snapshot = {
        .uri = "/snapshot",
        .method = HTTP_GET,
        .handler = snapshot_handler,
        .user_ctx = this,
    };
    httpd_uri_t status = {
        .uri = "/status",
        .method = HTTP_GET,
        .handler = status_handler,
        .user_ctx = this,
    };

    httpd_register_uri_handler(m_httpd, &root);
    httpd_register_uri_handler(m_httpd, &stream);
    httpd_register_uri_handler(m_httpd, &snapshot);
    httpd_register_uri_handler(m_httpd, &status);
    ESP_LOGI(TAG, "MJPEG server started on port %u: /stream /snapshot /status", static_cast<unsigned>(HTTP_PORT));
    return ESP_OK;
}

void CameraUploader::stop_http_server()
{
    if (m_httpd) {
        httpd_stop(m_httpd);
        m_httpd = nullptr;
    }
    if (m_frame_mutex && xSemaphoreTake(m_frame_mutex, portMAX_DELAY) == pdTRUE) {
        if (m_latest_frame) {
            heap_caps_free(m_latest_frame);
            m_latest_frame = nullptr;
            m_latest_frame_len = 0;
        }
        xSemaphoreGive(m_frame_mutex);
    }
}

esp_err_t CameraUploader::update_latest_frame(const who::cam::cam_fb_t *fb)
{
    void *copy = heap_caps_malloc(fb->len, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!copy) {
        copy = heap_caps_malloc(fb->len, MALLOC_CAP_8BIT);
    }
    if (!copy) {
        return ESP_ERR_NO_MEM;
    }
    std::memcpy(copy, fb->buf, fb->len);

    if (!m_frame_mutex || xSemaphoreTake(m_frame_mutex, pdMS_TO_TICKS(200)) != pdTRUE) {
        heap_caps_free(copy);
        return ESP_ERR_TIMEOUT;
    }

    if (m_latest_frame) {
        heap_caps_free(m_latest_frame);
    }
    m_latest_frame = static_cast<uint8_t *>(copy);
    m_latest_frame_len = fb->len;
    m_latest_width = fb->width;
    m_latest_height = fb->height;
    ++m_frame_seq;
    xSemaphoreGive(m_frame_mutex);

    ESP_LOGI(TAG,
             "updated MJPEG frame #%u: %ux%u len=%u",
             static_cast<unsigned>(m_frame_seq),
             static_cast<unsigned>(fb->width),
             static_cast<unsigned>(fb->height),
             static_cast<unsigned>(fb->len));
    return ESP_OK;
}

esp_err_t CameraUploader::prepare_frame_for_upload(const who::cam::cam_fb_t *src,
                                                   who::cam::cam_fb_t *dst,
                                                   void **prepared_buf)
{
    *prepared_buf = nullptr;
    if (src->format == who::cam::cam_fb_fmt_t::CAM_FB_FMT_RGB565 &&
        (src->width > UPLOAD_MAX_WIDTH || src->height > UPLOAD_MAX_HEIGHT)) {
        return downscale_rgb565(src, dst, prepared_buf);
    }

    void *copy = heap_caps_malloc(src->len, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!copy) {
        copy = heap_caps_malloc(src->len, MALLOC_CAP_8BIT);
    }
    if (!copy) {
        ESP_LOGW(TAG, "failed to allocate %u bytes for upload", static_cast<unsigned>(src->len));
        return ESP_ERR_NO_MEM;
    }

    *dst = *src;
    std::memcpy(copy, src->buf, src->len);
    dst->buf = copy;
    *prepared_buf = copy;
    return ESP_OK;
}

esp_err_t CameraUploader::downscale_rgb565(const who::cam::cam_fb_t *src, who::cam::cam_fb_t *dst, void **scaled_buf)
{
    uint16_t dst_width = src->width;
    uint16_t dst_height = src->height;
    while (dst_width > UPLOAD_MAX_WIDTH || dst_height > UPLOAD_MAX_HEIGHT) {
        dst_width /= 2;
        dst_height /= 2;
    }

    size_t dst_len = static_cast<size_t>(dst_width) * dst_height * 2;
    void *buf = heap_caps_malloc(dst_len, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!buf) {
        buf = heap_caps_malloc(dst_len, MALLOC_CAP_8BIT);
    }
    if (!buf) {
        ESP_LOGW(TAG, "failed to allocate %u bytes for scaled frame", static_cast<unsigned>(dst_len));
        return ESP_ERR_NO_MEM;
    }

    const uint16_t *src_pixels = static_cast<const uint16_t *>(src->buf);
    uint16_t *dst_pixels = static_cast<uint16_t *>(buf);
    for (uint16_t y = 0; y < dst_height; ++y) {
        uint32_t src_y = static_cast<uint32_t>(y) * src->height / dst_height;
        for (uint16_t x = 0; x < dst_width; ++x) {
            uint32_t src_x = static_cast<uint32_t>(x) * src->width / dst_width;
            dst_pixels[static_cast<size_t>(y) * dst_width + x] =
                src_pixels[static_cast<size_t>(src_y) * src->width + src_x];
        }
    }

    *dst = *src;
    dst->buf = buf;
    dst->len = dst_len;
    dst->width = dst_width;
    dst->height = dst_height;
    *scaled_buf = buf;

    ESP_LOGI(TAG,
             "scaled upload frame: %ux%u -> %ux%u",
             static_cast<unsigned>(src->width),
             static_cast<unsigned>(src->height),
             static_cast<unsigned>(dst->width),
             static_cast<unsigned>(dst->height));
    return ESP_OK;
}

esp_err_t CameraUploader::encode_frame_to_jpeg(const who::cam::cam_fb_t *src, who::cam::cam_fb_t *dst, void **jpeg_buf)
{
    *jpeg_buf = nullptr;
    if (src->format == who::cam::cam_fb_fmt_t::CAM_FB_FMT_JPEG) {
        *dst = *src;
        return ESP_OK;
    }

    jpeg_pixel_format_t src_type;
    switch (src->format) {
    case who::cam::cam_fb_fmt_t::CAM_FB_FMT_RGB565:
        src_type = JPEG_PIXEL_FORMAT_RGB565_LE;
        break;
    case who::cam::cam_fb_fmt_t::CAM_FB_FMT_RGB888:
        src_type = JPEG_PIXEL_FORMAT_RGB888;
        break;
    default:
        ESP_LOGW(TAG, "cannot JPEG encode unsupported source format=%s", frame_format_name(src->format));
        return ESP_ERR_NOT_SUPPORTED;
    }

    jpeg_enc_config_t config = DEFAULT_JPEG_ENC_CONFIG();
    config.width = src->width;
    config.height = src->height;
    config.src_type = src_type;
    config.subsampling = JPEG_SUBSAMPLE_420;
    config.quality = JPEG_QUALITY;
    config.rotate = JPEG_ROTATE_0D;
    config.task_enable = false;

    jpeg_enc_handle_t encoder = nullptr;
    if (jpeg_enc_open(&config, &encoder) != JPEG_ERR_OK || !encoder) {
        ESP_LOGW(TAG, "failed to open JPEG encoder");
        return ESP_FAIL;
    }

    size_t out_capacity = src->len;
    void *out = heap_caps_malloc(out_capacity, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!out) {
        out = heap_caps_malloc(out_capacity, MALLOC_CAP_8BIT);
    }
    if (!out) {
        ESP_LOGW(TAG, "failed to allocate %u bytes for JPEG output", static_cast<unsigned>(out_capacity));
        jpeg_enc_close(encoder);
        return ESP_ERR_NO_MEM;
    }

    int out_len = 0;
    jpeg_error_t enc_err = jpeg_enc_process(encoder,
                                            static_cast<const uint8_t *>(src->buf),
                                            static_cast<int>(src->len),
                                            static_cast<uint8_t *>(out),
                                            static_cast<int>(out_capacity),
                                            &out_len);
    jpeg_enc_close(encoder);
    if (enc_err != JPEG_ERR_OK || out_len <= 0) {
        ESP_LOGW(TAG, "JPEG encode failed err=%d out_len=%d", static_cast<int>(enc_err), out_len);
        heap_caps_free(out);
        return ESP_FAIL;
    }
    const uint8_t *jpeg = static_cast<const uint8_t *>(out);
    if (out_len < 4 || jpeg[0] != 0xff || jpeg[1] != 0xd8 || jpeg[out_len - 2] != 0xff || jpeg[out_len - 1] != 0xd9) {
        ESP_LOGW(TAG, "JPEG encode output has invalid markers len=%d", out_len);
        heap_caps_free(out);
        return ESP_FAIL;
    }

    *dst = *src;
    dst->buf = out;
    dst->len = static_cast<size_t>(out_len);
    dst->format = who::cam::cam_fb_fmt_t::CAM_FB_FMT_JPEG;
    *jpeg_buf = out;

    ESP_LOGI(TAG,
             "JPEG encoded: raw=%u jpeg=%u quality=%u",
             static_cast<unsigned>(src->len),
             static_cast<unsigned>(dst->len),
             static_cast<unsigned>(JPEG_QUALITY));
    return ESP_OK;
}

esp_err_t CameraUploader::root_handler(httpd_req_t *req)
{
    const char *html =
        "<!doctype html><html><head><meta charset=\"utf-8\">"
        "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
        "<title>ESP MJPEG</title></head>"
        "<body style=\"margin:0;background:#111;color:#eee;font-family:sans-serif;text-align:center\">"
        "<h2>ESP MJPEG Stream</h2><img src=\"/stream\" style=\"max-width:100%;height:auto\">"
        "<p><a style=\"color:#8cf\" href=\"/snapshot\">snapshot</a> "
        "<a style=\"color:#8cf\" href=\"/status\">status</a></p></body></html>";
    httpd_resp_set_type(req, "text/html");
    return httpd_resp_send(req, html, HTTPD_RESP_USE_STRLEN);
}

esp_err_t CameraUploader::stream_handler(httpd_req_t *req)
{
    auto *self = static_cast<CameraUploader *>(req->user_ctx);
    httpd_resp_set_type(req, "multipart/x-mixed-replace;boundary=FRAME");
    httpd_resp_set_hdr(req, "Cache-Control", "no-cache");

    while (true) {
        if (!self->m_frame_mutex || xSemaphoreTake(self->m_frame_mutex, pdMS_TO_TICKS(1000)) != pdTRUE) {
            vTaskDelay(pdMS_TO_TICKS(STREAM_DELAY_MS));
            continue;
        }

        bool has_frame = self->m_latest_frame && self->m_latest_frame_len > 0;
        esp_err_t err = ESP_OK;
        if (has_frame) {
            char header[128];
            int header_len = snprintf(header,
                                      sizeof(header),
                                      "--FRAME\r\nContent-Type: image/jpeg\r\nContent-Length: %u\r\n\r\n",
                                      static_cast<unsigned>(self->m_latest_frame_len));
            err = httpd_resp_send_chunk(req, header, header_len);
            if (err == ESP_OK) {
                err = httpd_resp_send_chunk(
                    req, reinterpret_cast<const char *>(self->m_latest_frame), self->m_latest_frame_len);
            }
            if (err == ESP_OK) {
                err = httpd_resp_send_chunk(req, "\r\n", 2);
            }
        }
        xSemaphoreGive(self->m_frame_mutex);

        if (err != ESP_OK) {
            break;
        }
        vTaskDelay(pdMS_TO_TICKS(STREAM_DELAY_MS));
    }

    return ESP_OK;
}

esp_err_t CameraUploader::snapshot_handler(httpd_req_t *req)
{
    auto *self = static_cast<CameraUploader *>(req->user_ctx);
    if (!self->m_frame_mutex || xSemaphoreTake(self->m_frame_mutex, pdMS_TO_TICKS(1000)) != pdTRUE) {
        httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "frame busy");
        return ESP_FAIL;
    }

    if (!self->m_latest_frame || self->m_latest_frame_len == 0) {
        xSemaphoreGive(self->m_frame_mutex);
        httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "no frame");
        return ESP_FAIL;
    }

    httpd_resp_set_type(req, "image/jpeg");
    esp_err_t err =
        httpd_resp_send(req, reinterpret_cast<const char *>(self->m_latest_frame), self->m_latest_frame_len);
    xSemaphoreGive(self->m_frame_mutex);
    return err;
}

esp_err_t CameraUploader::status_handler(httpd_req_t *req)
{
    auto *self = static_cast<CameraUploader *>(req->user_ctx);
    uint32_t seq = 0;
    size_t len = 0;
    uint16_t width = 0;
    uint16_t height = 0;

    if (self->m_frame_mutex && xSemaphoreTake(self->m_frame_mutex, pdMS_TO_TICKS(1000)) == pdTRUE) {
        seq = self->m_frame_seq;
        len = self->m_latest_frame_len;
        width = self->m_latest_width;
        height = self->m_latest_height;
        xSemaphoreGive(self->m_frame_mutex);
    }

    char json[160];
    int json_len = snprintf(json,
                            sizeof(json),
                            "{\"enabled\":%s,\"frames\":%u,\"width\":%u,\"height\":%u,\"len\":%u}",
                            self->m_enabled ? "true" : "false",
                            static_cast<unsigned>(seq),
                            static_cast<unsigned>(width),
                            static_cast<unsigned>(height),
                            static_cast<unsigned>(len));
    httpd_resp_set_type(req, "application/json");
    return httpd_resp_send(req, json, json_len);
}