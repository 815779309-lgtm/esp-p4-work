# Audio Prompts

Put wake prompt audio files here.

Recommended format:

- `wake.wav`
- 16 kHz
- 16-bit PCM
- mono

This format matches the speaker output path used by the voice control code.
