# Human Face Recognition Example

### Interaction

#### ESP-S3-EYE

Physical buttons

| btn  | opertion         |
|------|------------------|
| play | recognize        |
| up   | enroll           |
| down | delete last feat |

#### ESP-S3-KORVO-2

Physical buttons

| btn  | opertion         |
|------|------------------|
| play | recognize        |
| vol+ | enroll           |
| vol- | delete last feat |

#### ESP32-P4-Function-EV-Board

Touch screen buttons

| btn       | opertion         |
|-----------|------------------|
| recognize | recognize        |
| enroll    | enroll           |
| delete    | delete last feat |

Voice interaction is also enabled on ESP32-P4-Function-EV-Board:

| spoken command | operation  |
|----------------|------------|
| 人脸录入       | enroll     |
| 人脸识别       | recognize  |

When a face is detected, the board speaks: `识别到人脸`.

The voice feature uses ESP-SR. Flash with `idf.py flash` so the `model` partition is written; `idf.py app-flash` only updates the application and will not refresh the speech models.
