#!/usr/bin/env python3
# coding: utf-8
"""
从 RTSP 视频流拉取并分析，实时显示结果，同时控制舵机。
优化：每帧分析消除闪烁、数据面板两栏显示、GPU加速、低延迟拉流。
"""

import cv2
import mediapipe as mp
import numpy as np
import time
import socket
import threading
import json
from flask import Flask, Response, render_template_string, jsonify
import urllib.request
import urllib.error

# ============================
# 配置
# ============================
PROCESS_WIDTH = 224
PROCESS_HEIGHT = 168
USE_GPU = True
FACE_SKIP_FRAMES = 5
JPEG_QUALITY = 50
INITIAL_DROP = 30
PER_READ_DROP = 2

# ---------- 舵机参数 ----------
PWM_MIN = 500
PWM_MAX = 2500
PWM_MID = 1500
SERVO_TIME = 200
TRACK_TIME = 50

YAW_MIN, YAW_MAX = -60.0, 60.0
ANGLE_MIN, ANGLE_MAX = 0.0, 180.0
WRIST_ROTATION_MIN, WRIST_ROTATION_MAX = -90.0, 90.0

FACE_SMOOTH_FACTOR = 0.2
FACE_DEAD_ZONE = 2.0
FACE_GAIN = 0.6

WRIST_SMOOTH_FACTOR = 0.15
WRIST_DEAD_ZONE = 2.0
WRIST_GAIN = 3.0

SHOULDER_SMOOTH_FACTOR = 0.4
SHOULDER_DEAD_ZONE = 1.0

ELBOW_SMOOTH_FACTOR = 0.4
ELBOW_DEAD_ZONE = 1.0
SERVO2_INVERT = True
SERVO2_PWM_MIN = 1500
SERVO2_PWM_MAX = 2500

CMD_SERVER_IP = "118.190.200.73"
CMD_SERVER_PORT = 5002
CLOUD_UPLOAD_URL = f"http://{CMD_SERVER_IP}:8081/upload_processed"
CLOUD_RAW_STREAM_URL = f"http://{CMD_SERVER_IP}:8081/stream_raw"
STREAM_URL = "rtsp://zxh:12345678@192.168.187.136:8554/push_stream_name"
FLASK_PORT = 5000

# ============================
# 全局状态
# ============================
servo_values = [PWM_MID] * 6
filtered_yaw = 0.0
yaw_initialized = False
filtered_wrist_rotation = 0.0
wrist_initialized = False
filtered_shoulder_angle = 0.0
shoulder_initialized = False
filtered_elbow_complement = 0.0
elbow_initialized = False
servo4_dir = 1
servo4_step = 20
servo5_step = 30

latest_jpeg = None
latest_data = {
    "shoulder_deg": 0.0,
    "elbow_deg": 0.0,
    "wrist_rot_deg": 0.0,
    "face_yaw_deg": 0.0,
    "gesture": "None",
    "servo_pwm": [1500]*6,
}
data_lock = threading.Lock()
running = True
cmd_socket = None

# ============================
# 舵机函数
# ============================
def send_multi_servo(items, t=TRACK_TIME):
    if not items:
        return
    body = "".join(f"#{idx:03d}P{pwm:04d}T{t:04d}!" for idx, pwm in items)
    cmd = f"{{{body}}}\n".encode()
    if cmd_socket is not None:
        try:
            cmd_socket.sendall(cmd)
        except Exception:
            pass

def init_servo_socket():
    global cmd_socket
    try:
        cmd_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        cmd_socket.settimeout(2.0)
        cmd_socket.connect((CMD_SERVER_IP, CMD_SERVER_PORT))
        print(f"[OK] 已连接舵机中继 {CMD_SERVER_IP}:{CMD_SERVER_PORT}")
        init_cmds = [(i, PWM_MID) for i in range(6)]
        send_multi_servo(init_cmds, t=500)
        time.sleep(0.6)
        return True
    except Exception as e:
        print(f"[WARN] 舵机中继连接失败: {e}，舵机控制不可用")
        cmd_socket = None
        return False

# ============================
# 角度计算函数
# ============================
def angle_to_pwm(angle_deg, in_min, in_max):
    a = np.clip(angle_deg, in_min, in_max)
    pwm = int(PWM_MIN + (a - in_min) * (PWM_MAX - PWM_MIN) / (in_max - in_min))
    return max(PWM_MIN, min(PWM_MAX, pwm))

def calculate_angle(point1, point2, point3):
    p1 = np.array(point1)
    p2 = np.array(point2)
    p3 = np.array(point3)
    v1 = p1 - p2
    v2 = p3 - p2
    cos_angle = np.dot(v1, v2) / (np.linalg.norm(v1) * np.linalg.norm(v2) + 1e-6)
    angle = np.arccos(np.clip(cos_angle, -1.0, 1.0))
    return np.degrees(angle)

def get_landmark_coords(landmarks, index, frame_shape):
    h, w = frame_shape[:2]
    lm = landmarks.landmark[index]
    return (int(lm.x * w), int(lm.y * h))

def calculate_vector_angle(v1, v2):
    cos_angle = np.dot(v1, v2) / (np.linalg.norm(v1) * np.linalg.norm(v2) + 1e-6)
    return np.degrees(np.arccos(np.clip(cos_angle, -1.0, 1.0)))

def recognize_gesture(hand_landmarks):
    lm = hand_landmarks.landmark
    thumb_tip_y = lm[4].y
    thumb_ip_y = lm[3].y
    index_tip_y = lm[8].y
    index_dip_y = lm[6].y
    middle_tip_y = lm[12].y
    middle_dip_y = lm[10].y
    ring_tip_y = lm[16].y
    ring_dip_y = lm[14].y
    pinky_tip_y = lm[20].y
    pinky_dip_y = lm[18].y

    thumb_extended = thumb_tip_y < thumb_ip_y
    index_extended = index_tip_y < index_dip_y
    middle_extended = middle_tip_y < middle_dip_y
    ring_extended = ring_tip_y < ring_dip_y
    pinky_extended = pinky_tip_y < pinky_dip_y

    if index_extended and not middle_extended and not ring_extended and not pinky_extended:
        return "1"
    if index_extended and middle_extended and not ring_extended and not pinky_extended:
        return "2"
    if thumb_extended and pinky_extended and not index_extended and not middle_extended and not ring_extended:
        return "6"
    return None

def detect_face_angle(face_landmarks, frame_shape):
    h, w = frame_shape[:2]
    lm = face_landmarks.landmark
    nose_x = lm[1].x * w
    left_eye_x = lm[33].x * w
    right_eye_x = lm[263].x * w
    eye_center_x = (left_eye_x + right_eye_x) / 2.0
    eye_distance = np.hypot(right_eye_x - left_eye_x, 0)
    if eye_distance < 1e-6:
        return None
    offset = (nose_x - eye_center_x) / eye_distance
    raw_yaw = np.degrees(np.arctan(offset * 2.5)) * FACE_GAIN
    if abs(raw_yaw) < FACE_DEAD_ZONE:
        raw_yaw = 0.0
    return raw_yaw, 0.0, 0.0

def get_wrist_rotation_angle(hand_landmarks, frame_shape):
    h, w = frame_shape[:2]
    lm = hand_landmarks.landmark
    wrist_pinky = np.array([lm[17].x * w, lm[17].y * h])
    wrist_thumb = np.array([lm[5].x * w, lm[5].y * h])
    wrist_vec = wrist_thumb - wrist_pinky
    wrist_vec = wrist_vec / (np.linalg.norm(wrist_vec) + 1e-6)
    horizontal = np.array([1, 0])
    cos_angle = np.dot(wrist_vec, horizontal) / (np.linalg.norm(wrist_vec) + 1e-6)
    angle = np.degrees(np.arccos(np.clip(cos_angle, -1.0, 1.0)))
    if wrist_vec[1] < 0:
        angle = -angle
    return np.clip(angle, WRIST_ROTATION_MIN, WRIST_ROTATION_MAX)

# ============================
# 平滑函数
# ============================
def smooth_yaw(raw_yaw):
    global filtered_yaw, yaw_initialized
    if not yaw_initialized:
        filtered_yaw = raw_yaw
        yaw_initialized = True
        return filtered_yaw
    filtered_yaw = filtered_yaw * (1 - FACE_SMOOTH_FACTOR) + raw_yaw * FACE_SMOOTH_FACTOR
    return filtered_yaw

def smooth_wrist(raw_angle):
    global filtered_wrist_rotation, wrist_initialized
    if not wrist_initialized:
        filtered_wrist_rotation = raw_angle
        wrist_initialized = True
        return filtered_wrist_rotation
    filtered_wrist_rotation = filtered_wrist_rotation * (1 - WRIST_SMOOTH_FACTOR) + raw_angle * WRIST_SMOOTH_FACTOR
    return filtered_wrist_rotation

def smooth_shoulder(raw_angle):
    global filtered_shoulder_angle, shoulder_initialized
    if not shoulder_initialized:
        filtered_shoulder_angle = raw_angle
        shoulder_initialized = True
        return filtered_shoulder_angle
    filtered_shoulder_angle = filtered_shoulder_angle * (1 - SHOULDER_SMOOTH_FACTOR) + raw_angle * SHOULDER_SMOOTH_FACTOR
    return filtered_shoulder_angle

def smooth_elbow(raw_angle):
    global filtered_elbow_complement, elbow_initialized
    if not elbow_initialized:
        filtered_elbow_complement = raw_angle
        elbow_initialized = True
        return filtered_elbow_complement
    filtered_elbow_complement = filtered_elbow_complement * (1 - ELBOW_SMOOTH_FACTOR) + raw_angle * ELBOW_SMOOTH_FACTOR
    return filtered_elbow_complement

# ============================
# 帧分析函数
# ============================
def analyze_frame(frame, pose, hands, face_mesh, frame_count):
    global servo_values, servo4_dir
    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    h, w = frame.shape[:2]

    pose_results = pose.process(frame_rgb)
    hand_results = hands.process(frame_rgb)
    face_results = None
    if frame_count % FACE_SKIP_FRAMES == 0:
        face_results = face_mesh.process(frame_rgb)

    data = {
        "shoulder_deg": 0.0,
        "elbow_deg": 0.0,
        "wrist_rot_deg": 0.0,
        "face_yaw_deg": 0.0,
        "gesture": "None",
        "servo_pwm": servo_values.copy(),
    }
    servo_cmds = []

    if pose_results.pose_landmarks:
        landmarks = pose_results.pose_landmarks
        right_shoulder = get_landmark_coords(landmarks, 12, (h, w))
        right_elbow = get_landmark_coords(landmarks, 14, (h, w))
        right_wrist = get_landmark_coords(landmarks, 16, (h, w))

        if all([right_shoulder, right_elbow, right_wrist]):
            elbow_angle = calculate_angle(right_shoulder, right_elbow, right_wrist)
            vec_shoulder_elbow = np.array(right_elbow) - np.array(right_shoulder)
            vertical_down = np.array([0, 1])
            shoulder_angle = calculate_vector_angle(vec_shoulder_elbow, vertical_down)

            data["shoulder_deg"] = shoulder_angle
            data["elbow_deg"] = elbow_angle

            gesture = None
            wrist_rot = None
            if hand_results.multi_hand_landmarks:
                for i, hand_lm in enumerate(hand_results.multi_hand_landmarks):
                    handedness = ""
                    if hand_results.multi_handedness and i < len(hand_results.multi_handedness):
                        handedness = hand_results.multi_handedness[i].classification[0].label
                    g = recognize_gesture(hand_lm)
                    wr = get_wrist_rotation_angle(hand_lm, (h, w))
                    if handedness == "Right":
                        gesture = g
                        wrist_rot = wr
                    elif gesture is None:
                        gesture = g
                        wrist_rot = wr
            data["gesture"] = gesture if gesture else "None"
            if wrist_rot is not None:
                data["wrist_rot_deg"] = wrist_rot

            # 舵机映射
            raw_shoulder = shoulder_angle
            if abs(raw_shoulder - 90) < SHOULDER_DEAD_ZONE:
                raw_shoulder = 90
            smoothed_shoulder = smooth_shoulder(raw_shoulder)
            pwm1 = int(PWM_MID - (smoothed_shoulder / 180.0) * (PWM_MID - PWM_MIN))
            pwm1 = max(PWM_MIN, min(PWM_MID, pwm1))
            if abs(pwm1 - servo_values[1]) >= 5:
                servo_values[1] = pwm1
                servo_cmds.append((1, pwm1))

            raw_complement = 180.0 - elbow_angle
            if abs(raw_complement - 90) < ELBOW_DEAD_ZONE:
                raw_complement = 90
            smoothed_complement = smooth_elbow(raw_complement)
            if SERVO2_INVERT:
                pwm2 = int(SERVO2_PWM_MIN + (smoothed_complement / 180.0) * (SERVO2_PWM_MAX - SERVO2_PWM_MIN))
            else:
                pwm2 = int(SERVO2_PWM_MAX - (smoothed_complement / 180.0) * (SERVO2_PWM_MAX - SERVO2_PWM_MIN))
            pwm2 = max(SERVO2_PWM_MIN, min(SERVO2_PWM_MAX, pwm2))
            if abs(pwm2 - servo_values[2]) >= 5:
                servo_values[2] = pwm2
                servo_cmds.append((2, pwm2))

            if wrist_rot is not None:
                raw_angle = wrist_rot * WRIST_GAIN
                if abs(raw_angle) < WRIST_DEAD_ZONE:
                    raw_angle = 0.0
                raw_angle = np.clip(raw_angle, WRIST_ROTATION_MIN, WRIST_ROTATION_MAX)
                smoothed_angle = smooth_wrist(raw_angle)
                normalized = (smoothed_angle - WRIST_ROTATION_MIN) / (WRIST_ROTATION_MAX - WRIST_ROTATION_MIN)
                pwm3 = int(PWM_MID + normalized * (PWM_MAX - PWM_MID))
                pwm3 = max(PWM_MID, min(PWM_MAX, pwm3))
                if abs(pwm3 - servo_values[3]) >= 5:
                    servo_values[3] = pwm3
                    servo_cmds.append((3, pwm3))

            if gesture == "1":
                servo_values[4] += servo4_dir * servo4_step
                if servo_values[4] >= PWM_MAX:
                    servo_values[4] = PWM_MAX
                    servo4_dir = -1
                elif servo_values[4] <= PWM_MIN:
                    servo_values[4] = PWM_MIN
                    servo4_dir = 1
                servo_cmds.append((4, servo_values[4]))
            elif gesture == "2":
                servo_values[5] = min(PWM_MAX, servo_values[5] + servo5_step)
                servo_cmds.append((5, servo_values[5]))
            elif gesture == "6":
                servo_values[5] = max(PWM_MIN, servo_values[5] - servo5_step)
                servo_cmds.append((5, servo_values[5]))

    if face_results and face_results.multi_face_landmarks:
        for face_lm in face_results.multi_face_landmarks:
            angles = detect_face_angle(face_lm, (h, w))
            if angles is not None:
                raw_yaw = angles[0]
                smoothed_yaw = smooth_yaw(raw_yaw)
                data["face_yaw_deg"] = smoothed_yaw
                pwm0 = angle_to_pwm(smoothed_yaw, YAW_MIN, YAW_MAX)
                if abs(pwm0 - servo_values[0]) >= 5:
                    servo_values[0] = pwm0
                    servo_cmds.append((0, pwm0))

    if servo_cmds:
        send_multi_servo(servo_cmds, t=TRACK_TIME)

    data["servo_pwm"] = servo_values.copy()

    # 绘制标注
    ann_frame = frame.copy()
    if pose_results.pose_landmarks:
        mp.solutions.drawing_utils.draw_landmarks(
            ann_frame, pose_results.pose_landmarks, mp.solutions.pose.POSE_CONNECTIONS,
            mp.solutions.drawing_utils.DrawingSpec(color=(0,255,0), thickness=1, circle_radius=1),
            mp.solutions.drawing_utils.DrawingSpec(color=(0,0,255), thickness=1)
        )
    if hand_results and hand_results.multi_hand_landmarks:
        for hand_lm in hand_results.multi_hand_landmarks:
            mp.solutions.drawing_utils.draw_landmarks(
                ann_frame, hand_lm, mp.solutions.hands.HAND_CONNECTIONS,
                mp.solutions.drawing_utils.DrawingSpec(color=(255,0,0), thickness=1, circle_radius=1),
                mp.solutions.drawing_utils.DrawingSpec(color=(0,255,255), thickness=1)
            )
    if face_results and face_results.multi_face_landmarks:
        for face_lm in face_results.multi_face_landmarks:
            for idx in [1, 33, 263, 61, 291]:
                x = int(face_lm.landmark[idx].x * w)
                y = int(face_lm.landmark[idx].y * h)
                cv2.circle(ann_frame, (x, y), 2, (0, 255, 255), -1)

    return ann_frame, data

# ============================
# OpenCV 拉流生成器
# ============================
def opencv_frame_generator(url, target_width=PROCESS_WIDTH, target_height=PROCESS_HEIGHT):
    while running:
        cap = cv2.VideoCapture(url, cv2.CAP_FFMPEG)
        if not cap.isOpened():
            print("[STREAM] OpenCV 无法打开流，重试...")
            time.sleep(2)
            continue
        cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        print(f"[STREAM] OpenCV 成功打开流: {url}")
        print(f"[STREAM] 丢弃初始 {INITIAL_DROP} 帧...")
        for _ in range(INITIAL_DROP):
            if not cap.grab():
                break
        while running:
            for _ in range(PER_READ_DROP):
                if not cap.grab():
                    break
            ret, frame = cap.retrieve()
            if not ret:
                print("[STREAM] 读取失败，重连...")
                break
            frame = cv2.resize(frame, (target_width, target_height))
            yield frame
        cap.release()
        if running:
            print("[STREAM] 重连中...")
            time.sleep(2)

# ============================
# 处理线程（每帧分析）
# ============================
def processing_thread():
    global latest_jpeg, latest_data, running
    mp_pose = mp.solutions.pose
    mp_hands = mp.solutions.hands
    mp_face_mesh = mp.solutions.face_mesh

    try:
        pose = mp_pose.Pose(
            static_image_mode=False,
            model_complexity=0,
            smooth_landmarks=True,
            min_detection_confidence=0.6,
            min_tracking_confidence=0.5,
            use_gpu=USE_GPU
        )
        hands = mp_hands.Hands(
            static_image_mode=False,
            max_num_hands=2,
            min_detection_confidence=0.7,
            min_tracking_confidence=0.6,
            use_gpu=USE_GPU
        )
        face_mesh = mp_face_mesh.FaceMesh(
            static_image_mode=False,
            max_num_faces=1,
            min_detection_confidence=0.7,
            min_tracking_confidence=0.6,
            use_gpu=USE_GPU
        )
        if USE_GPU:
            print("[INFO] 已尝试启用 GPU 加速")
    except TypeError:
        pose = mp_pose.Pose(
            static_image_mode=False,
            model_complexity=0,
            smooth_landmarks=True,
            min_detection_confidence=0.6,
            min_tracking_confidence=0.5
        )
        hands = mp_hands.Hands(
            static_image_mode=False,
            max_num_hands=2,
            min_detection_confidence=0.7,
            min_tracking_confidence=0.6
        )
        face_mesh = mp_face_mesh.FaceMesh(
            static_image_mode=False,
            max_num_faces=1,
            min_detection_confidence=0.7,
            min_tracking_confidence=0.6
        )
        print("[INFO] 使用 CPU 模式（use_gpu 参数不被支持）")

    frame_count = 0
    for raw_frame in opencv_frame_generator(STREAM_URL):
        if not running:
            break
        frame_count += 1
        ann_frame, data = analyze_frame(raw_frame, pose, hands, face_mesh, frame_count)

        ret, jpg = cv2.imencode('.jpg', ann_frame, [cv2.IMWRITE_JPEG_QUALITY, JPEG_QUALITY])
        if ret:
            jpeg_data = jpg.tobytes()
            with data_lock:
                latest_jpeg = jpeg_data
                latest_data = data

    pose.close()
    hands.close()
    face_mesh.close()
    print("[THREAD] 处理线程结束")

# ============================
# Flask Web 服务器（数据面板两栏布局）
# ============================
app = Flask(__name__)

@app.route('/')
def index():
    cloud_stream_url = CLOUD_RAW_STREAM_URL
    return render_template_string('''
    <!DOCTYPE html>
    <html>
    <head>
        <title>双路视频监控</title>
        <style>
            * { margin:0; padding:0; box-sizing:border-box; }
            body { background: #1a1a2e; color: #eee; font-family: 'Segoe UI', sans-serif; height: 100vh; overflow: hidden; }
            h1 { text-align: center; color: #e94560; padding: 8px 0; font-size: 24px; }
            .container { display: flex; flex-wrap: nowrap; gap: 15px; padding: 0 20px 20px 20px; height: calc(100vh - 60px); }
            .video-box { background: #16213e; border-radius: 12px; padding: 10px; display: flex; flex-direction: column; flex: 1; min-width: 0; }
            .video-box h2 { text-align: center; color: #0f3460; font-size: 16px; margin-bottom: 6px; }
            .video-wrapper { display: flex; flex: 1; gap: 12px; min-height: 0; align-items: stretch; }
            .video-wrapper img { flex: 1; width: 100%; border-radius: 8px; border: 2px solid #0f3460; object-fit: contain; min-width: 0; }
            /* 数据面板样式：两栏布局 */
            .data-panel { 
                width: 200px; 
                background: #0f3460; 
                border-radius: 8px; 
                padding: 12px 16px; 
                font-size: 14px; 
                display: flex; 
                flex-direction: column; 
                justify-content: center; 
                color: #eee; 
                flex-shrink: 0; 
                box-shadow: 0 0 15px rgba(0,0,0,0.3);
            }
            .data-panel .row { 
                display: flex; 
                justify-content: space-between; 
                padding: 5px 0; 
                border-bottom: 1px solid rgba(255,255,255,0.08); 
            }
            .data-panel .row:last-child { border-bottom: none; }
            .data-panel .label { 
                color: #e94560; 
                font-weight: 500; 
                text-align: left; 
                flex: 0 0 auto; 
                margin-right: 20px;
            }
            .data-panel .value { 
                font-weight: bold; 
                color: #4fc3f7; 
                text-align: right; 
                flex: 1; 
                font-family: 'Consolas', monospace;
            }
            .info { margin-top: 6px; display: flex; justify-content: center; gap: 30px; font-size: 14px; }
            .info span { color: #e94560; }
            @media (max-width: 900px) {
                .data-panel { width: 150px; font-size: 12px; padding: 10px; }
                .data-panel .label { margin-right: 10px; }
            }
        </style>
    </head>
    <body>
        <h1>🤖 双路视频监控</h1>
        <div class="container">
            <!-- 左侧：本地处理后视频 + 数据面板 -->
            <div class="video-box">
                <h2>🖥️ 本地处理后视频</h2>
                <div class="video-wrapper">
                    <img src="/video_feed" alt="处理后视频">
                    <div class="data-panel" id="data-panel">
                        <div class="row"><span class="label">肩</span><span class="value" id="shoulder">0.0</span>°</div>
                        <div class="row"><span class="label">肘</span><span class="value" id="elbow">0.0</span>°</div>
                        <div class="row"><span class="label">腕旋转</span><span class="value" id="wrist">0.0</span>°</div>
                        <div class="row"><span class="label">面朝向</span><span class="value" id="face">0.0</span>°</div>
                        <div class="row"><span class="label">手势</span><span class="value" id="gesture">None</span></div>
                        <div class="row"><span class="label">PWM0</span><span class="value" id="pwm0">1500</span></div>
                        <div class="row"><span class="label">PWM1</span><span class="value" id="pwm1">1500</span></div>
                        <div class="row"><span class="label">PWM2</span><span class="value" id="pwm2">1500</span></div>
                        <div class="row"><span class="label">PWM3</span><span class="value" id="pwm3">1500</span></div>
                        <div class="row"><span class="label">PWM4</span><span class="value" id="pwm4">1500</span></div>
                        <div class="row"><span class="label">PWM5</span><span class="value" id="pwm5">1500</span></div>
                    </div>
                </div>
            </div>
            <!-- 右侧：云端原始视频 -->
            <div class="video-box" style="flex:0.8;">
                <h2>📷 ESP32-S3 原始视频（云端）</h2>
                <div style="flex:1; display:flex;">
                    <img src="{{ cloud_url }}" alt="原始视频" style="width:100%; border-radius:8px; border:2px solid #0f3460; object-fit:contain;">
                </div>
            </div>
        </div>
        <div class="info">
            <span>舵机中继: {{ "已连接" if cmd_socket else "未连接" }}</span>
        </div>
        <script>
            function fetchData() {
                fetch('/data')
                    .then(response => response.json())
                    .then(data => {
                        document.getElementById('shoulder').textContent = data.shoulder_deg.toFixed(1);
                        document.getElementById('elbow').textContent = data.elbow_deg.toFixed(1);
                        document.getElementById('wrist').textContent = data.wrist_rot_deg.toFixed(1);
                        document.getElementById('face').textContent = data.face_yaw_deg.toFixed(1);
                        document.getElementById('gesture').textContent = data.gesture;
                        const pwm = data.servo_pwm;
                        document.getElementById('pwm0').textContent = pwm[0];
                        document.getElementById('pwm1').textContent = pwm[1];
                        document.getElementById('pwm2').textContent = pwm[2];
                        document.getElementById('pwm3').textContent = pwm[3];
                        document.getElementById('pwm4').textContent = pwm[4];
                        document.getElementById('pwm5').textContent = pwm[5];
                    })
                    .catch(() => {});
            }
            setInterval(fetchData, 200);
            fetchData();
        </script>
    </body>
    </html>
    ''', cloud_url=cloud_stream_url, cmd_socket=cmd_socket is not None)

@app.route('/video_feed')
def video_feed():
    def generate():
        global latest_jpeg
        while running:
            jpeg_data = None
            with data_lock:
                if latest_jpeg is not None:
                    jpeg_data = latest_jpeg
            if jpeg_data is None:
                time.sleep(0.001)
                continue
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n'
                   b'Cache-Control: no-cache, no-store, must-revalidate\r\n'
                   b'Pragma: no-cache\r\n'
                   b'Expires: 0\r\n\r\n' + jpeg_data + b'\r\n')
    return Response(generate(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/data')
def get_data():
    with data_lock:
        return jsonify(latest_data)

# ============================
# 主函数
# ============================
def main():
    global running
    init_servo_socket()

    t = threading.Thread(target=processing_thread, daemon=True)
    t.start()

    print(f"[WEB] 启动本地服务，访问 http://127.0.0.1:{FLASK_PORT}")
    print(f"[WEB] 右侧视频将从云端拉取: {CLOUD_RAW_STREAM_URL}")
    try:
        app.run(host='0.0.0.0', port=FLASK_PORT, threaded=True)
    except KeyboardInterrupt:
        print("退出...")
    finally:
        running = False
        if cmd_socket:
            cmd_socket.close()
        print("程序结束")

if __name__ == '__main__':
    main()
#最终版本