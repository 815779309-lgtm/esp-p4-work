#include <stdio.h>
#include <string.h>
#include <inttypes.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"
#include "freertos/semphr.h"
#include "esp_system.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_log.h"
#include "nvs_flash.h"
#include "esp_netif.h"
#include "esp_camera.h"
#include "esp_timer.h"
#include "driver/uart.h"
#include "driver/gpio.h"
#include "lwip/err.h"
#include "lwip/sockets.h"
#include "lwip/sys.h"
#include "lwip/netdb.h"

static const char *TAG = "CAM_STREAM";

/* ==================== WiFi STA 配置 ==================== */
#define WIFI_SSID      "弦歌湖的鱼"
#define WIFI_PASSWORD  "Zzx.750108"
#define WIFI_MAX_RETRY 5

/* ==================== 云端服务器配置 ==================== */
#define CLOUD_SERVER_IP   "118.190.200.73"
#define CLOUD_SERVER_PORT 5000
#define CMD_SERVER_PORT   5001

/* ==================== UART 舵机总线配置 ==================== */
#define UART_PORT_NUM      UART_NUM_1
#define UART_TX_PIN        43
#define UART_RX_PIN        44
#define UART_TX_EN_PIN     3
#define UART_RX_EN_PIN     46
#define UART_BAUD_RATE     115200
#define UART_BUF_SIZE      256
#define BUS_SERVO_TX_DONE_TIMEOUT_MS 100

/* ==================== 舵机参数配置 ==================== */
#define BUS_SERVO_MIN_PULSE     500
#define BUS_SERVO_CENTER_PULSE  1500
#define BUS_SERVO_MAX_PULSE     2500
#define BUS_SERVO_MOVE_TIME_MS  1000
#define SERVO_MIN_ANGLE         0
#define SERVO_MAX_ANGLE         180
#define SERVO_INIT_ANGLE        90
#define SERVO_COUNT             6
#define SERVO_DEADZONE          15
#define SERVO_INTERPOLATE_PERIOD_MS 20

/* ==================== 摄像头配置 ==================== */
/* Freenove ESP32-S3 CAM + OV5640 引脚定义 */
#define CAM_PIN_PWDN    -1
#define CAM_PIN_RESET   -1
#define CAM_PIN_XCLK    15
#define CAM_PIN_SIOD    4
#define CAM_PIN_SIOC    5

#define CAM_PIN_D7      16
#define CAM_PIN_D6      17
#define CAM_PIN_D5      18
#define CAM_PIN_D4      12
#define CAM_PIN_D3      10
#define CAM_PIN_D2      8
#define CAM_PIN_D1      9
#define CAM_PIN_D0      11
#define CAM_PIN_VSYNC   6
#define CAM_PIN_HREF    7
#define CAM_PIN_PCLK    13

/* 图像参数 */
#define CAM_FRAME_SIZE   FRAMESIZE_VGA    /* 640x480 */
#define CAM_JPEG_QUALITY 12               /* 0-63, 越小质量越高 */
#define CAM_FB_COUNT     2                /* 帧缓冲数量 */

/* ==================== WiFi 事件组 ==================== */
static EventGroupHandle_t s_wifi_event_group;
#define WIFI_CONNECTED_BIT BIT0
#define WIFI_FAIL_BIT      BIT1

static int s_retry_num = 0;

/* ==================== WiFi 事件处理 ==================== */
static void wifi_event_handler(void *arg, esp_event_base_t event_base,
                               int32_t event_id, void *event_data)
{
    if (event_base == WIFI_EVENT && event_id == WIFI_EVENT_STA_START) {
        esp_wifi_connect();
    } else if (event_base == WIFI_EVENT && event_id == WIFI_EVENT_STA_DISCONNECTED) {
        if (s_retry_num < WIFI_MAX_RETRY) {
            esp_wifi_connect();
            s_retry_num++;
            ESP_LOGW(TAG, "WiFi 断开，重连第 %d 次", s_retry_num);
        } else {
            xEventGroupSetBits(s_wifi_event_group, WIFI_FAIL_BIT);
            ESP_LOGE(TAG, "WiFi 连接失败，已达最大重试次数");
        }
    } else if (event_base == IP_EVENT && event_id == IP_EVENT_STA_GOT_IP) {
        ip_event_got_ip_t *event = (ip_event_got_ip_t *)event_data;
        ESP_LOGI(TAG, "WiFi 已连接，IP: " IPSTR, IP2STR(&event->ip_info.ip));
        s_retry_num = 0;
        xEventGroupSetBits(s_wifi_event_group, WIFI_CONNECTED_BIT);
    }
}

/* ==================== WiFi STA 初始化 ==================== */
static esp_err_t wifi_init_sta(void)
{
    s_wifi_event_group = xEventGroupCreate();

    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    esp_netif_create_default_wifi_sta();

    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));

    esp_event_handler_instance_t instance_any_id;
    esp_event_handler_instance_t instance_got_ip;
    ESP_ERROR_CHECK(esp_event_handler_instance_register(WIFI_EVENT,
                                                        ESP_EVENT_ANY_ID,
                                                        &wifi_event_handler,
                                                        NULL,
                                                        &instance_any_id));
    ESP_ERROR_CHECK(esp_event_handler_instance_register(IP_EVENT,
                                                        IP_EVENT_STA_GOT_IP,
                                                        &wifi_event_handler,
                                                        NULL,
                                                        &instance_got_ip));

    wifi_config_t wifi_config = {
        .sta = {
            .ssid = WIFI_SSID,
            .password = WIFI_PASSWORD,
            .threshold.authmode = WIFI_AUTH_WPA2_PSK,
        },
    };
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_STA, &wifi_config));
    ESP_ERROR_CHECK(esp_wifi_start());

    ESP_LOGI(TAG, "WiFi STA 初始化完成");

    EventBits_t bits = xEventGroupWaitBits(s_wifi_event_group,
                                           WIFI_CONNECTED_BIT | WIFI_FAIL_BIT,
                                           pdFALSE,
                                           pdFALSE,
                                           portMAX_DELAY);

    if (bits & WIFI_CONNECTED_BIT) {
        ESP_LOGI(TAG, "WiFi 连接成功: %s", WIFI_SSID);
        return ESP_OK;
    } else if (bits & WIFI_FAIL_BIT) {
        ESP_LOGE(TAG, "WiFi 连接失败: %s", WIFI_SSID);
        return ESP_FAIL;
    } else {
        ESP_LOGE(TAG, "WiFi 意外事件");
        return ESP_FAIL;
    }
}

/* ==================== 摄像头初始化 ==================== */
static esp_err_t camera_init(void)
{
    camera_config_t config = {
        .pin_pwdn       = CAM_PIN_PWDN,
        .pin_reset      = CAM_PIN_RESET,
        .pin_xclk       = CAM_PIN_XCLK,
        .pin_sccb_sda   = CAM_PIN_SIOD,
        .pin_sccb_scl   = CAM_PIN_SIOC,

        .pin_d7         = CAM_PIN_D7,
        .pin_d6         = CAM_PIN_D6,
        .pin_d5         = CAM_PIN_D5,
        .pin_d4         = CAM_PIN_D4,
        .pin_d3         = CAM_PIN_D3,
        .pin_d2         = CAM_PIN_D2,
        .pin_d1         = CAM_PIN_D1,
        .pin_d0         = CAM_PIN_D0,
        .pin_vsync      = CAM_PIN_VSYNC,
        .pin_href       = CAM_PIN_HREF,
        .pin_pclk       = CAM_PIN_PCLK,

        .xclk_freq_hz   = 20000000,           /* 20MHz XCLK */
        .ledc_timer     = LEDC_TIMER_0,
        .ledc_channel   = LEDC_CHANNEL_0,

        .pixel_format   = PIXFORMAT_JPEG,
        .frame_size     = CAM_FRAME_SIZE,
        .jpeg_quality   = CAM_JPEG_QUALITY,
        .fb_count       = CAM_FB_COUNT,
        .grab_mode      = CAMERA_GRAB_WHEN_EMPTY,
    };

    esp_err_t err = esp_camera_init(&config);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "摄像头初始化失败: 0x%x", err);
        return err;
    }

    /* 可选：配置 OV5640 特殊寄存器 */
    sensor_t *s = esp_camera_sensor_get();
    if (s != NULL) {
        s->set_brightness(s, 0);      /* -2 ~ 2 */
        s->set_contrast(s, 0);        /* -2 ~ 2 */
        s->set_saturation(s, 0);      /* -2 ~ 2 */
        s->set_sharpness(s, 0);       /* -2 ~ 2 */
        s->set_whitebal(s, 1);        /* 自动白平衡 */
        s->set_awb_gain(s, 1);        /* 自动白平衡增益 */
        s->set_exposure_ctrl(s, 1);   /* 自动曝光 */
        s->set_aec2(s, 1);            /* 自动曝光控制2 */
        s->set_gain_ctrl(s, 1);       /* 自动增益 */
        s->set_agc_gain(s, 0);        /* 自动增益值 */
        s->set_gainceiling(s, (gainceiling_t)0); /* 增益上限 2x */
        s->set_bpc(s, 0);             /* 黑点校正 */
        s->set_wpc(s, 1);             /* 白点校正 */
        s->set_raw_gma(s, 1);         /* Gamma校正 */
        s->set_lenc(s, 1);            /* 镜头校正 */
        s->set_hmirror(s, 0);         /* 水平镜像 */
        s->set_vflip(s, 0);           /* 垂直翻转 */
        s->set_dcw(s, 1);             /* 下采样 */
        s->set_colorbar(s, 0);        /* 彩条 */
        s->set_special_effect(s, 0);  /* 特效 */
        s->set_quality(s, CAM_JPEG_QUALITY);
        s->set_framesize(s, CAM_FRAME_SIZE);
    }

    ESP_LOGI(TAG, "摄像头初始化成功: OV5640, %dx%d",
             config.frame_size == FRAMESIZE_VGA ? 640 : 320,
             config.frame_size == FRAMESIZE_VGA ? 480 : 240);
    return ESP_OK;
}



/* ==================== 舵机状态管理 ==================== */
typedef struct {
    int32_t current_pwm;
    int32_t target_pwm;
    int32_t start_pwm;
    int32_t move_duration_ms;
    int32_t elapsed_ms;
    bool moving;
} servo_state_t;

static servo_state_t s_servo_states[SERVO_COUNT];
static SemaphoreHandle_t s_servo_lock = NULL;
static SemaphoreHandle_t s_servo_state_lock = NULL;

static esp_err_t bus_servo_send_raw(const char* command);

static void servo_state_init(void)
{
    for (int i = 0; i < SERVO_COUNT; i++) {
        s_servo_states[i].current_pwm = BUS_SERVO_CENTER_PULSE;
        s_servo_states[i].target_pwm = BUS_SERVO_CENTER_PULSE;
        s_servo_states[i].start_pwm = BUS_SERVO_CENTER_PULSE;
        s_servo_states[i].move_duration_ms = BUS_SERVO_MOVE_TIME_MS;
        s_servo_states[i].elapsed_ms = 0;
        s_servo_states[i].moving = false;
    }
}

static void servo_set_target(int servo_id, int32_t target_pwm, int32_t duration_ms)
{
    if (servo_id < 0 || servo_id >= SERVO_COUNT) {
        return;
    }

    xSemaphoreTake(s_servo_state_lock, portMAX_DELAY);

    if (abs(target_pwm - s_servo_states[servo_id].current_pwm) < SERVO_DEADZONE) {
        xSemaphoreGive(s_servo_state_lock);
        return;
    }

    s_servo_states[servo_id].start_pwm = s_servo_states[servo_id].current_pwm;
    s_servo_states[servo_id].target_pwm = target_pwm;
    s_servo_states[servo_id].move_duration_ms = (duration_ms > 0) ? duration_ms : BUS_SERVO_MOVE_TIME_MS;
    s_servo_states[servo_id].elapsed_ms = 0;
    s_servo_states[servo_id].moving = true;

    xSemaphoreGive(s_servo_state_lock);
}

static void servo_update_targets_from_command(const char* command)
{
    if (command == NULL || strlen(command) == 0) {
        return;
    }

    const char* ptr = command;
    while (*ptr != '\0') {
        if (*ptr != '#') {
            ptr++;
            continue;
        }

        ptr++;

        int servo_id = 0;
        while (*ptr >= '0' && *ptr <= '9') {
            servo_id = servo_id * 10 + (*ptr - '0');
            ptr++;
        }

        if (*ptr != 'P') {
            while (*ptr != '\0' && *ptr != '#' && *ptr != '!') {
                ptr++;
            }
            if (*ptr == '!') {
                ptr++;
            }
            continue;
        }
        ptr++;

        int32_t target_pwm = 0;
        bool has_pwm_digits = false;
        while (*ptr >= '0' && *ptr <= '9') {
            target_pwm = target_pwm * 10 + (*ptr - '0');
            has_pwm_digits = true;
            ptr++;
        }

        if (!has_pwm_digits) {
            while (*ptr != '\0' && *ptr != '#' && *ptr != '!') {
                ptr++;
            }
            if (*ptr == '!') {
                ptr++;
            }
            continue;
        }

        int32_t duration_ms = BUS_SERVO_MOVE_TIME_MS;
        if (*ptr == 'T') {
            ptr++;
            duration_ms = 0;
            while (*ptr >= '0' && *ptr <= '9') {
                duration_ms = duration_ms * 10 + (*ptr - '0');
                ptr++;
            }
        }

        servo_set_target(servo_id, target_pwm, duration_ms);

        while (*ptr != '\0' && *ptr != '#' && *ptr != '!') {
            ptr++;
        }
        if (*ptr == '!') {
            ptr++;
        }
    }
}

static void servo_interpolate_task(void *pvParameters)
{
    ESP_LOGI(TAG, "舵机插值任务启动，周期: %dms", SERVO_INTERPOLATE_PERIOD_MS);

    while (1) {
        char cmd_buf[64];

        xSemaphoreTake(s_servo_state_lock, portMAX_DELAY);

        for (int i = 0; i < SERVO_COUNT; i++) {
            if (!s_servo_states[i].moving) {
                continue;
            }

            s_servo_states[i].elapsed_ms += SERVO_INTERPOLATE_PERIOD_MS;

            if (s_servo_states[i].elapsed_ms >= s_servo_states[i].move_duration_ms) {
                s_servo_states[i].current_pwm = s_servo_states[i].target_pwm;
                s_servo_states[i].moving = false;
            } else {
                float progress = (float)s_servo_states[i].elapsed_ms / s_servo_states[i].move_duration_ms;
                s_servo_states[i].current_pwm = s_servo_states[i].start_pwm +
                    (int32_t)((s_servo_states[i].target_pwm - s_servo_states[i].start_pwm) * progress);
            }

            snprintf(cmd_buf, sizeof(cmd_buf), "#%03dP%" PRId32 "T%d!",
                     i, s_servo_states[i].current_pwm, SERVO_INTERPOLATE_PERIOD_MS);
            bus_servo_send_raw(cmd_buf);
        }

        xSemaphoreGive(s_servo_state_lock);

        vTaskDelay(pdMS_TO_TICKS(SERVO_INTERPOLATE_PERIOD_MS));
    }
}

/* ==================== 差分驱动方向控制 ==================== */
static void bus_servo_set_receive_mode(void)
{
    gpio_set_level(UART_TX_EN_PIN, 0);
    gpio_set_level(UART_RX_EN_PIN, 1);
}

static void bus_servo_set_transmit_mode(void)
{
    gpio_set_level(UART_RX_EN_PIN, 0);
    gpio_set_level(UART_TX_EN_PIN, 1);
}

/* ==================== 安全的舵机命令发送 ==================== */
static esp_err_t bus_servo_send_raw(const char* command)
{
    if (command == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    xSemaphoreTake(s_servo_lock, portMAX_DELAY);

    uart_flush_input(UART_PORT_NUM);
    bus_servo_set_transmit_mode();

    const int command_len = strlen(command);
    const int written = uart_write_bytes(UART_PORT_NUM, command, command_len);
    if (written != command_len) {
        bus_servo_set_receive_mode();
        xSemaphoreGive(s_servo_lock);
        ESP_LOGW(TAG, "UART write failed: %d/%d bytes", written, command_len);
        return ESP_FAIL;
    }

    esp_err_t err = uart_wait_tx_done(UART_PORT_NUM, pdMS_TO_TICKS(BUS_SERVO_TX_DONE_TIMEOUT_MS));
    bus_servo_set_receive_mode();
    xSemaphoreGive(s_servo_lock);

    if (err != ESP_OK) {
        ESP_LOGW(TAG, "UART TX wait failed: %s", esp_err_to_name(err));
    }
    return err;
}

/* ==================== UART 初始化 ==================== */
static void uart_init(void)
{
    if (s_servo_lock == NULL) {
        s_servo_lock = xSemaphoreCreateMutex();
        if (s_servo_lock == NULL) {
            ESP_LOGE(TAG, "Failed to create servo lock");
            abort();
        }
    }

    if (s_servo_state_lock == NULL) {
        s_servo_state_lock = xSemaphoreCreateMutex();
        if (s_servo_state_lock == NULL) {
            ESP_LOGE(TAG, "Failed to create servo state lock");
            abort();
        }
    }

    uart_config_t uart_config = {
        .baud_rate = UART_BAUD_RATE,
        .data_bits = UART_DATA_8_BITS,
        .parity    = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_DEFAULT,
    };

    ESP_ERROR_CHECK(uart_driver_install(UART_PORT_NUM, UART_BUF_SIZE,
                                        UART_BUF_SIZE, 0, NULL, 0));
    ESP_ERROR_CHECK(uart_param_config(UART_PORT_NUM, &uart_config));
    ESP_ERROR_CHECK(uart_set_pin(UART_PORT_NUM, UART_TX_PIN, UART_RX_PIN,
                                 UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE));

    const gpio_config_t en_gpio_config = {
        .pin_bit_mask = (1ULL << UART_TX_EN_PIN) | (1ULL << UART_RX_EN_PIN),
        .mode = GPIO_MODE_OUTPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    ESP_ERROR_CHECK(gpio_config(&en_gpio_config));
    bus_servo_set_receive_mode();

    ESP_LOGI(TAG, "UART舵机总线初始化完成: TX=GPIO%d, RX=GPIO%d, TX_EN=GPIO%d, RX_EN=GPIO%d, Baud=%d",
             UART_TX_PIN, UART_RX_PIN, UART_TX_EN_PIN, UART_RX_EN_PIN, UART_BAUD_RATE);
}

/* ==================== 舵机硬件初始化 ==================== */
static void servo_hardware_init(void)
{
    ESP_LOGI(TAG, "初始化舵机参数...");

    bus_servo_send_raw("#000PMOD1!");
    bus_servo_send_raw("#001PMOD1!");
    bus_servo_send_raw("#002PMOD1!");
    bus_servo_send_raw("#003PMOD1!");
    bus_servo_send_raw("#004PMOD1!");
    bus_servo_send_raw("#005PMOD1!");
    vTaskDelay(pdMS_TO_TICKS(100));

    bus_servo_send_raw("#000PULR!");
    bus_servo_send_raw("#001PULR!");
    bus_servo_send_raw("#002PULR!");
    bus_servo_send_raw("#003PULR!");
    bus_servo_send_raw("#004PULR!");
    bus_servo_send_raw("#005PULR!");
    vTaskDelay(pdMS_TO_TICKS(100));

    ESP_LOGI(TAG, "舵机初始化完成");
}

/* ==================== TCP 连接 ==================== */
static int tcp_connect(const char *host, int port)
{
    struct sockaddr_in server_addr;
    int sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (sock < 0) {
        ESP_LOGE(TAG, "创建 socket 失败: errno %d", errno);
        return -1;
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port);
    server_addr.sin_addr.s_addr = inet_addr(host);

    ESP_LOGI(TAG, "正在连接云端 %s:%d ...", host, port);
    int ret = connect(sock, (struct sockaddr *)&server_addr, sizeof(server_addr));
    if (ret != 0) {
        ESP_LOGE(TAG, "连接云端失败: errno %d", errno);
        close(sock);
        return -1;
    }

    ESP_LOGI(TAG, "已连接到云端 %s:%d", host, port);
    return sock;
}

/* ==================== 发送帧数据 ==================== */
static int tcp_send_frame(int sock, const uint8_t *data, size_t len)
{
    if (sock < 0 || data == NULL || len == 0) {
        return -1;
    }

    uint32_t frame_len_be = htonl((uint32_t)len);

    int sent = send(sock, &frame_len_be, sizeof(frame_len_be), 0);
    if (sent != sizeof(frame_len_be)) {
        ESP_LOGE(TAG, "发送帧头失败: %d/%d, errno %d", sent, (int)sizeof(frame_len_be), errno);
        return -1;
    }

    size_t total_sent = 0;
    while (total_sent < len) {
        sent = send(sock, data + total_sent, len - total_sent, 0);
        if (sent <= 0) {
            ESP_LOGE(TAG, "发送帧数据失败: %d, errno %d", sent, errno);
            return -1;
        }
        total_sent += sent;
    }

    return 0;
}

/* ==================== 指令接收任务 ==================== */
static const char *TAG_CMD = "CMD_RECV";

void cmd_receiver_task(void *pvParameters)
{
    int sock = -1;
    char rx_buffer[UART_BUF_SIZE];

    ESP_LOGI(TAG_CMD, "========== 舵机指令接收任务启动 ==========");

    while (1) {
        if (sock < 0) {
            sock = tcp_connect(CLOUD_SERVER_IP, CMD_SERVER_PORT);
            if (sock < 0) {
                ESP_LOGW(TAG_CMD, "5秒后重试连接指令通道...");
                vTaskDelay(pdMS_TO_TICKS(5000));
                continue;
            }
            ESP_LOGI(TAG_CMD, "指令通道已连接: %s:%d", CLOUD_SERVER_IP, CMD_SERVER_PORT);
        }

        int len = recv(sock, rx_buffer, UART_BUF_SIZE - 1, 0);
        if (len <= 0) {
            ESP_LOGE(TAG_CMD, "指令通道断开 (errno=%d)", errno);
            close(sock);
            sock = -1;
            vTaskDelay(pdMS_TO_TICKS(1000));
            continue;
        }

        rx_buffer[len] = '\0';

        if (rx_buffer[0] == '$') {
            bus_servo_send_raw(rx_buffer);
            ESP_LOGI(TAG_CMD, "直接转发特殊指令: %s", rx_buffer);
        } else if (strstr(rx_buffer, "PMOD") != NULL || strstr(rx_buffer, "PULR") != NULL) {
            bus_servo_send_raw(rx_buffer);
            ESP_LOGI(TAG_CMD, "直接转发配置指令: %s", rx_buffer);
        } else {
            servo_update_targets_from_command(rx_buffer);
            ESP_LOGI(TAG_CMD, "解析插值指令: %s", rx_buffer);
        }

        vTaskDelay(pdMS_TO_TICKS(5));
    }
}

/* ==================== 主任务：摄像头推流 ==================== */
void cam_stream_task(void *pvParameters)
{
    int sock = -1;
    uint32_t frame_count = 0;
    int64_t last_time = esp_timer_get_time();
    int64_t fps_report_time = last_time;

    ESP_LOGI(TAG, "========== 摄像头推流任务启动 ==========");

    while (1) {
        if (sock < 0) {
            sock = tcp_connect(CLOUD_SERVER_IP, CLOUD_SERVER_PORT);
            if (sock < 0) {
                ESP_LOGW(TAG, "5秒后重试连接...");
                vTaskDelay(pdMS_TO_TICKS(5000));
                continue;
            }
        }

        camera_fb_t *fb = esp_camera_fb_get();
        if (!fb) {
            ESP_LOGE(TAG, "获取摄像头帧失败");
            vTaskDelay(pdMS_TO_TICKS(100));
            continue;
        }

        int ret = tcp_send_frame(sock, fb->buf, fb->len);
        esp_camera_fb_return(fb);

        if (ret != 0) {
            ESP_LOGE(TAG, "发送帧失败，断开连接");
            close(sock);
            sock = -1;
            vTaskDelay(pdMS_TO_TICKS(1000));
            continue;
        }

        frame_count++;

        int64_t now = esp_timer_get_time();
        if (now - fps_report_time >= 5000000) {
            float fps = (float)frame_count * 1000000.0f / (float)(now - fps_report_time);
            ESP_LOGI(TAG, "推流中... FPS: %.1f, 已发送帧数: %" PRIu32, fps, frame_count);
            fps_report_time = now;
            frame_count = 0;
        }

        vTaskDelay(pdMS_TO_TICKS(10));
    }
}

/* ==================== 应用入口 ==================== */
void app_main(void)
{
    ESP_LOGI(TAG, "========================================");
    ESP_LOGI(TAG, "  ESP32-S3 CAM STA 模式 + 舵机控制");
    ESP_LOGI(TAG, "  WiFi: %s", WIFI_SSID);
    ESP_LOGI(TAG, "  推流: %s:%d", CLOUD_SERVER_IP, CLOUD_SERVER_PORT);
    ESP_LOGI(TAG, "  指令: %s:%d", CLOUD_SERVER_IP, CMD_SERVER_PORT);
    ESP_LOGI(TAG, "========================================");

    /* 初始化 NVS */
    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ret = nvs_flash_init();
    }
    ESP_ERROR_CHECK(ret);

    /* 连接 WiFi */
    ESP_LOGI(TAG, "正在连接 WiFi...");
    ESP_ERROR_CHECK(wifi_init_sta());

    /* 初始化摄像头 */
    ESP_LOGI(TAG, "正在初始化摄像头...");
    ESP_ERROR_CHECK(camera_init());

    /* 初始化 UART 舵机总线 */
    ESP_LOGI(TAG, "正在初始化舵机总线...");
    uart_init();

    /* 初始化舵机状态 */
    servo_state_init();

    /* 初始化舵机硬件 */
    servo_hardware_init();

    /* 创建推流任务 */
    xTaskCreate(cam_stream_task, "cam_stream", 8192, NULL, 5, NULL);

    /* 创建指令接收任务 */
    xTaskCreate(cmd_receiver_task, "cmd_recv", 6144, NULL, 5, NULL);

    /* 创建舵机插值任务 */
    xTaskCreate(servo_interpolate_task, "servo_interp", 4096, NULL, 4, NULL);

    ESP_LOGI(TAG, "系统启动完成！");
}