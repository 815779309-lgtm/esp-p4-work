#!/usr/bin/env python3
"""
ESP32-S3 CAM 云端接收服务器
============================
功能：
  - 监听 TCP 5000 端口，接收 ESP32 CAM 发来的 JPEG 帧
  - 保存 JPEG 帧到本地文件
  - 提供 HTTP MJPEG 视频流，可用浏览器实时查看

协议：
  [4字节帧长度(大端)] + [JPEG数据]

使用方法:
  1. 在阿里云服务器上运行: python3 cloud_receiver.py
  2. 浏览器打开 http://<服务器IP>:8080 查看实时画面
  3. 接收的帧保存在 ./captured_frames/ 目录下

依赖:
  pip3 install pillow   (可选，用于图像处理)
"""

import socket
import struct
import threading
import os
import time
import sys
from http.server import HTTPServer, BaseHTTPRequestHandler
from datetime import datetime

# ==================== 配置 ====================
TCP_PORT = 5000
ESP32_CMD_PORT = 5001
CLIENT_CMD_PORT = 5002
HTTP_PORT = 8080
SAVE_DIR = "./captured_frames"
MAX_SAVED_FRAMES = 100  # 最多保存帧数，超过则自动清理
JPEG_QUALITY = 85


class FrameBuffer:
    """线程安全的帧缓冲区"""

    def __init__(self):
        self._lock = threading.Lock()
        self._frame = None
        self._timestamp = 0
        self._frame_count = 0

    def update(self, jpeg_data: bytes):
        with self._lock:
            self._frame = jpeg_data
            self._timestamp = time.time()
            self._frame_count += 1

    def get(self):
        with self._lock:
            if self._frame is None:
                return None
            return self._frame, self._timestamp, self._frame_count


class MJPEGHandler(BaseHTTPRequestHandler):
    """HTTP MJPEG 流处理器"""

    frame_buffer: FrameBuffer = None

    def do_GET(self):
        if self.path == "/":
            self._serve_html()
        elif self.path == "/stream":
            self._serve_mjpeg()
        elif self.path == "/snapshot":
            self._serve_snapshot()
        elif self.path == "/status":
            self._serve_status()
        else:
            self.send_error(404)

    def _serve_html(self):
        html = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ESP32-S3 CAM 实时画面</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { background: #1a1a2e; color: #eee; font-family: 'Segoe UI', sans-serif;
         display: flex; flex-direction: column; align-items: center; min-height: 100vh; }
  h1 { margin: 20px 0; color: #e94560; font-size: 28px; }
  .container { position: relative; max-width: 800px; width: 100%; padding: 0 20px; }
  img { width: 100%; border-radius: 12px; border: 3px solid #0f3460; box-shadow: 0 0 30px rgba(233,69,96,0.3); }
  .info { margin-top: 16px; padding: 12px 20px; background: #16213e; border-radius: 8px;
          font-size: 14px; display: flex; justify-content: space-between; }
  .info span { color: #e94560; font-weight: bold; }
  .status { display: inline-block; width: 10px; height: 10px; border-radius: 50%;
             background: #00ff88; animation: pulse 1.5s infinite; margin-right: 6px; }
  @keyframes pulse { 0%,100% { opacity: 1; } 50% { opacity: 0.3; } }
  a { color: #0f3460; }
</style>
</head>
<body>
<h1>ESP32-S3 CAM 实时监控画面</h1>
<div class="container">
  <img id="stream" src="/stream" alt="实时画面" />
  <div class="info">
    <span><span class="status"></span> 实时推流中</span>
    <span id="fps">- FPS</span>
    <span id="time">-</span>
  </div>
</div>
<script>
  const img = document.getElementById('stream');
  const fpsEl = document.getElementById('fps');
  const timeEl = document.getElementById('time');
  let lastTime = 0, frameCount = 0;
  img.onload = () => {
    frameCount++;
    const now = Date.now();
    if (now - lastTime >= 2000) {
      const fps = (frameCount / ((now - lastTime) / 1000)).toFixed(1);
      fpsEl.textContent = fps + ' FPS';
      lastTime = now;
      frameCount = 0;
    }
    timeEl.textContent = new Date().toLocaleTimeString('zh-CN');
  };
  img.onerror = () => { img.src = '/stream?' + Date.now(); };
</script>
</body>
</html>"""
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(html.encode("utf-8"))))
        self.end_headers()
        self.wfile.write(html.encode("utf-8"))

    def _serve_mjpeg(self):
        self.send_response(200)
        self.send_header("Content-Type",
                         "multipart/x-mixed-replace; boundary=FRAME")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Connection", "close")
        self.end_headers()

        try:
            while True:
                data = self.frame_buffer.get()
                if data is None:
                    time.sleep(0.1)
                    continue

                jpeg_data, _, _ = data
                self.wfile.write(b"--FRAME\r\n")
                self.wfile.write(b"Content-Type: image/jpeg\r\n")
                self.wfile.write(
                    f"Content-Length: {len(jpeg_data)}\r\n\r\n".encode()
                )
                self.wfile.write(jpeg_data)
                self.wfile.write(b"\r\n")
                time.sleep(0.03)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _serve_snapshot(self):
        data = self.frame_buffer.get()
        if data is None:
            self.send_error(503, "No frame available")
            return
        jpeg_data, _, _ = data
        self.send_response(200)
        self.send_header("Content-Type", "image/jpeg")
        self.send_header("Content-Length", str(len(jpeg_data)))
        self.end_headers()
        self.wfile.write(jpeg_data)

    def _serve_status(self):
        data = self.frame_buffer.get()
        if data is None:
            status = '{"status":"waiting","frames":0}'
        else:
            _, ts, count = data
            status = f'{{"status":"streaming","frames":{count},"last_frame":"{datetime.fromtimestamp(ts).isoformat()}"}}'
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(status)))
        self.end_headers()
        self.wfile.write(status.encode())

    def log_message(self, format, *args):
        pass  # 静默日志


class TCPServer:
    """TCP 接收服务器"""

    def __init__(self, host="0.0.0.0", port=TCP_PORT):
        self.host = host
        self.port = port
        self.frame_buffer = FrameBuffer()
        self.running = False
        self.save_dir = SAVE_DIR
        self.saved_count = 0
        self.esp32_sock = None
        self.esp32_lock = threading.Lock()

        os.makedirs(self.save_dir, exist_ok=True)

    def set_esp32_sock(self, sock):
        with self.esp32_lock:
            self.esp32_sock = sock

    def get_esp32_sock(self):
        with self.esp32_lock:
            return self.esp32_sock

    def start(self):
        self.running = True
        server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server_sock.bind((self.host, self.port))
        server_sock.listen(1)
        server_sock.settimeout(1.0)

        print(f"[TCP] 监听端口 {self.port}，等待 ESP32 CAM 连接...")

        while self.running:
            try:
                client_sock, addr = server_sock.accept()
                print(f"[TCP] ESP32 CAM 已连接: {addr[0]}:{addr[1]}")
                self._handle_client(client_sock, addr)
            except socket.timeout:
                continue
            except Exception as e:
                if self.running:
                    print(f"[TCP] 错误: {e}")

        server_sock.close()

    def _handle_client(self, client_sock, addr):
        client_sock.settimeout(10.0)
        frame_count = 0
        last_report = time.time()

        self.set_esp32_sock(client_sock)
        print(f"[TCP] ESP32 CAM 已连接: {addr[0]}:{addr[1]} (指令通道已就绪)")

        try:
            while self.running:
                header = self._recv_exact(client_sock, 4)
                if header is None:
                    break

                frame_len = struct.unpack(">I", header)[0]

                if frame_len == 0 or frame_len > 10 * 1024 * 1024:
                    print(f"[TCP] 无效帧长度: {frame_len}，断开连接")
                    break

                jpeg_data = self._recv_exact(client_sock, frame_len)
                if jpeg_data is None:
                    break

                if len(jpeg_data) < 2 or jpeg_data[0] != 0xFF or jpeg_data[1] != 0xD8:
                    print(f"[TCP] 非 JPEG 数据，跳过帧")
                    continue

                self.frame_buffer.update(jpeg_data)
                frame_count += 1

                self._save_frame(jpeg_data)

                now = time.time()
                if now - last_report >= 5.0:
                    fps = frame_count / (now - last_report) if last_report > 0 else 0
                    print(f"[TCP] 接收中... FPS: {fps:.1f}, 帧大小: {len(jpeg_data)}B, "
                          f"总帧数: {self.frame_buffer._frame_count}")
                    frame_count = 0
                    last_report = now

        except (ConnectionResetError, BrokenPipeError, OSError) as e:
            print(f"[TCP] 连接断开: {e}")
        finally:
            self.set_esp32_sock(None)
            client_sock.close()
            print(f"[TCP] ESP32 CAM 已断开: {addr[0]}:{addr[1]}")

    def _recv_exact(self, sock, n):
        data = b""
        while len(data) < n:
            try:
                chunk = sock.recv(n - len(data))
            except socket.timeout:
                return None
            if not chunk:
                return None
            data += chunk
        return data

    def _save_frame(self, jpeg_data):
        self.saved_count += 1
        filename = os.path.join(
            self.save_dir,
            f"frame_{self.saved_count:06d}_{datetime.now().strftime('%H%M%S')}.jpg"
        )
        try:
            with open(filename, "wb") as f:
                f.write(jpeg_data)
        except Exception as e:
            print(f"[保存] 写入失败: {e}")

        # 自动清理旧帧
        if self.saved_count % 50 == 0:
            self._cleanup_old_frames()

    def _cleanup_old_frames(self):
        try:
            files = sorted(
                [f for f in os.listdir(self.save_dir) if f.endswith(".jpg")],
                key=lambda x: os.path.getmtime(os.path.join(self.save_dir, x))
            )
            while len(files) > MAX_SAVED_FRAMES:
                os.remove(os.path.join(self.save_dir, files[0]))
                files.pop(0)
        except Exception:
            pass

    def stop(self):
        self.running = False


class CmdServer:
    """舵机指令转发服务器"""

    def __init__(self, host="0.0.0.0"):
        self.host = host
        self.running = False
        self.esp32_sock = None
        self.esp32_lock = threading.Lock()

    def set_esp32_sock(self, sock):
        with self.esp32_lock:
            self.esp32_sock = sock

    def get_esp32_sock(self):
        with self.esp32_lock:
            return self.esp32_sock

    def _handle_esp32(self, client_sock, addr):
        client_sock.settimeout(30.0)
        self.set_esp32_sock(client_sock)
        print(f"[CMD] ESP32 指令通道已连接: {addr[0]}:{addr[1]}")

        try:
            while self.running:
                try:
                    data = client_sock.recv(1024)
                except socket.timeout:
                    continue
                if not data:
                    break
        except (ConnectionResetError, BrokenPipeError, OSError):
            pass
        finally:
            self.set_esp32_sock(None)
            client_sock.close()
            print(f"[CMD] ESP32 指令通道已断开: {addr[0]}:{addr[1]}")

    def _handle_client(self, client_sock, addr):
        client_sock.settimeout(5.0)
        print(f"[CMD] 控制端已连接: {addr[0]}:{addr[1]}")

        try:
            while self.running:
                try:
                    data = client_sock.recv(1024)
                except socket.timeout:
                    continue
                if not data:
                    break

                esp32_sock = self.get_esp32_sock()
                if esp32_sock is None:
                    print(f"[CMD] ESP32 未连接，丢弃 {len(data)} 字节指令")
                    continue

                try:
                    esp32_sock.sendall(data)
                    print(f"[CMD] 转发 {len(data)} 字节到 ESP32")
                except (ConnectionResetError, BrokenPipeError, OSError) as e:
                    print(f"[CMD] 发送到 ESP32 失败: {e}")
                    self.set_esp32_sock(None)
                    break
        except (ConnectionResetError, BrokenPipeError, OSError) as e:
            print(f"[CMD] 控制端断开: {e}")
        finally:
            client_sock.close()
            print(f"[CMD] 控制端已断开: {addr[0]}:{addr[1]}")

    def start(self):
        self.running = True

        esp32_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        esp32_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        esp32_sock.bind((self.host, ESP32_CMD_PORT))
        esp32_sock.listen(1)
        esp32_sock.settimeout(1.0)

        client_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        client_sock.bind((self.host, CLIENT_CMD_PORT))
        client_sock.listen(5)
        client_sock.settimeout(1.0)

        print(f"[CMD] 监听 ESP32 指令端口 {ESP32_CMD_PORT}")
        print(f"[CMD] 监听控制端端口 {CLIENT_CMD_PORT}")

        while self.running:
            try:
                conn, addr = esp32_sock.accept()
                threading.Thread(target=self._handle_esp32, args=(conn, addr), daemon=True).start()
            except socket.timeout:
                pass
            except Exception as e:
                if self.running:
                    print(f"[CMD] ESP32 端口错误: {e}")

            try:
                conn, addr = client_sock.accept()
                threading.Thread(target=self._handle_client, args=(conn, addr), daemon=True).start()
            except socket.timeout:
                pass
            except Exception as e:
                if self.running:
                    print(f"[CMD] 控制端端口错误: {e}")

        esp32_sock.close()
        client_sock.close()

    def stop(self):
        self.running = False


def main():
    print("=" * 50)
    print("  ESP32-S3 CAM 云端接收服务器")
    print("=" * 50)
    print(f"  TCP 视频端口: {TCP_PORT}")
    print(f"  ESP32 指令端口: {ESP32_CMD_PORT}")
    print(f"  控制端指令端口: {CLIENT_CMD_PORT}")
    print(f"  HTTP 查看端口: {HTTP_PORT} (若被占用将自动尝试下一个)")
    print(f"  帧保存目录: {os.path.abspath(SAVE_DIR)}")
    print("=" * 50)

    # 创建 TCP 服务器
    tcp_server = TCPServer(port=TCP_PORT)

    # 创建指令转发服务器
    cmd_server = CmdServer()

    # 设置 HTTP 处理器的帧缓冲区
    MJPEGHandler.frame_buffer = tcp_server.frame_buffer

    # 自动寻找可用 HTTP 端口
    http_port = HTTP_PORT
    http_server = None
    while http_port < HTTP_PORT + 20:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind(("0.0.0.0", http_port))
            sock.close()
            http_server = HTTPServer(("0.0.0.0", http_port), MJPEGHandler)
            break
        except OSError as e:
            if e.errno == 98:
                print(f"[HTTP] 端口 {http_port} 已被占用，尝试下一个...")
                http_port += 1
            else:
                raise
    if http_server is None:
        print("[错误] 无法找到可用 HTTP 端口，请手动释放 8080 附近端口。")
        sys.exit(1)

    if http_port != HTTP_PORT:
        print(f"[HTTP] 实际使用端口: {http_port}")

    http_thread = threading.Thread(target=http_server.serve_forever, daemon=True)
    http_thread.start()

    cmd_thread = threading.Thread(target=cmd_server.start, daemon=True)
    cmd_thread.start()

    print(f"\n[HTTP] 浏览器打开 http://<服务器IP>:{http_port} 查看实时画面")
    print(f"[CMD] 控制端连接 TCP <服务器IP>:{CLIENT_CMD_PORT} 发送舵机指令\n")

    try:
        tcp_server.start()
    except KeyboardInterrupt:
        print("\n[系统] 正在关闭...")
        tcp_server.stop()
        cmd_server.stop()
        http_server.shutdown()
        print("[系统] 已关闭")
        sys.exit(0)

if __name__ == "__main__":
    main()